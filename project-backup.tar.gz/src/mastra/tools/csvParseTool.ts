import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { parse } from "csv-parse/sync";

export const parseCsvTool = createTool({
  id: "parse-csv",
  description:
    "Parses CSV content into structured data. Returns an array of objects where each object represents a row with column headers as keys.",

  inputSchema: z.object({
    csvContent: z.string().describe("The raw CSV content to parse"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    rows: z.array(z.record(z.string())).optional(),
    rowCount: z.number().optional(),
    columns: z.array(z.string()).optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📊 [parseCsvTool] Starting CSV parsing...");

    try {
      if (!context.csvContent || context.csvContent.trim() === "") {
        logger?.error("❌ [parseCsvTool] Empty CSV content provided");
        return {
          success: false,
          error: "Empty CSV content provided",
        };
      }

      logger?.info(`📝 [parseCsvTool] Parsing CSV content (${context.csvContent.length} chars)...`);

      const records = parse(context.csvContent, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
        bom: true,
      });

      if (!Array.isArray(records) || records.length === 0) {
        logger?.info("📭 [parseCsvTool] No data rows found in CSV");
        return {
          success: true,
          rows: [],
          rowCount: 0,
          columns: [],
        };
      }

      const columns = Object.keys(records[0] as Record<string, string>);

      logger?.info(`✅ [parseCsvTool] Successfully parsed ${records.length} rows with ${columns.length} columns`);
      logger?.info(`📋 [parseCsvTool] Columns: ${columns.join(", ")}`);

      return {
        success: true,
        rows: records as Record<string, string>[],
        rowCount: records.length,
        columns,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [parseCsvTool] Error parsing CSV: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to parse CSV: ${errorMessage}`,
      };
    }
  },
});
