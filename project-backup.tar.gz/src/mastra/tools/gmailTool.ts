import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { google } from "googleapis";

export const fetchGmailAttachmentTool = createTool({
  id: "fetch-gmail-attachment",
  description:
    "Fetches the latest email with a CSV attachment from Gmail. Returns the CSV content as a string.",

  inputSchema: z.object({
    searchQuery: z
      .string()
      .optional()
      .describe("Optional Gmail search query to filter emails (e.g., 'from:sender@example.com')"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    csvContent: z.string().optional(),
    filename: z.string().optional(),
    subject: z.string().optional(),
    from: z.string().optional(),
    date: z.string().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📧 [fetchGmailAttachmentTool] Starting Gmail fetch...");

    try {
      const clientEmail = process.env.GMAIL_SERVICE_ACCOUNT_EMAIL;
      const privateKey = process.env.GMAIL_SERVICE_ACCOUNT_PRIVATE_KEY?.replace(/\\n/g, "\n");
      const userEmail = process.env.GMAIL_USER_EMAIL;

      if (!clientEmail || !privateKey || !userEmail) {
        logger?.error("❌ [fetchGmailAttachmentTool] Missing Gmail credentials");
        return {
          success: false,
          error: "Gmail credentials not configured. Please set GMAIL_SERVICE_ACCOUNT_EMAIL, GMAIL_SERVICE_ACCOUNT_PRIVATE_KEY, and GMAIL_USER_EMAIL.",
        };
      }

      logger?.info("🔐 [fetchGmailAttachmentTool] Authenticating with Gmail API...");

      const auth = new google.auth.JWT({
        email: clientEmail,
        key: privateKey,
        scopes: ["https://www.googleapis.com/auth/gmail.readonly"],
        subject: userEmail,
      });

      const gmail = google.gmail({ version: "v1", auth });

      const searchQuery = context.searchQuery
        ? `has:attachment filename:csv ${context.searchQuery}`
        : "has:attachment filename:csv";

      logger?.info(`🔍 [fetchGmailAttachmentTool] Searching for emails with query: ${searchQuery}`);

      const listResponse = await gmail.users.messages.list({
        userId: "me",
        q: searchQuery,
        maxResults: 1,
      });

      const messages = listResponse.data.messages;
      if (!messages || messages.length === 0) {
        logger?.info("📭 [fetchGmailAttachmentTool] No emails with CSV attachments found");
        return {
          success: false,
          error: "No emails with CSV attachments found matching the search criteria.",
        };
      }

      const messageId = messages[0].id!;
      logger?.info(`📬 [fetchGmailAttachmentTool] Found message ID: ${messageId}`);

      const message = await gmail.users.messages.get({
        userId: "me",
        id: messageId,
      });

      const headers = message.data.payload?.headers || [];
      const subject = headers.find((h) => h.name === "Subject")?.value || "No Subject";
      const from = headers.find((h) => h.name === "From")?.value || "Unknown";
      const date = headers.find((h) => h.name === "Date")?.value || "Unknown";

      logger?.info(`📝 [fetchGmailAttachmentTool] Email - Subject: ${subject}, From: ${from}`);

      const parts = message.data.payload?.parts || [];
      let csvAttachment: { filename: string; attachmentId: string } | null = null;

      function findCsvAttachment(partsList: any[]): void {
        for (const part of partsList) {
          if (part.filename && part.filename.toLowerCase().endsWith(".csv") && part.body?.attachmentId) {
            csvAttachment = {
              filename: part.filename,
              attachmentId: part.body.attachmentId,
            };
            return;
          }
          if (part.parts) {
            findCsvAttachment(part.parts);
          }
        }
      }

      findCsvAttachment(parts as any[]);

      if (!csvAttachment) {
        logger?.error("❌ [fetchGmailAttachmentTool] No CSV attachment found in the email");
        return {
          success: false,
          error: "No CSV attachment found in the latest email.",
          subject,
          from,
          date,
        };
      }

      const foundAttachment = csvAttachment as { filename: string; attachmentId: string };
      logger?.info(`📎 [fetchGmailAttachmentTool] Found CSV attachment: ${foundAttachment.filename}`);

      const attachmentData = await gmail.users.messages.attachments.get({
        userId: "me",
        messageId: messageId,
        id: foundAttachment.attachmentId,
      });

      const base64Data = attachmentData.data.data || "";
      const csvContent = Buffer.from(base64Data, "base64url").toString("utf-8");

      logger?.info(`✅ [fetchGmailAttachmentTool] Successfully fetched CSV content (${csvContent.length} chars)`);

      return {
        success: true,
        csvContent,
        filename: foundAttachment.filename,
        subject,
        from,
        date,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [fetchGmailAttachmentTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to fetch Gmail attachment: ${errorMessage}`,
      };
    }
  },
});
