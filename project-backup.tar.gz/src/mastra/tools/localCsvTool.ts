import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { readFileSync, existsSync, readdirSync, statSync } from "fs";
import { join, resolve } from "path";

const PROJECT_ROOT = process.env.REPL_HOME || process.cwd();
const CSV_FOLDER = join(PROJECT_ROOT, "data");

export const fetchLocalCsvTool = createTool({
  id: "fetch-local-csv",
  description:
    "Fetches the most recent CSV file from the data folder. Upload your CSV files to the 'data' folder in the project.",

  inputSchema: z.object({
    folder: z
      .string()
      .optional()
      .describe("Optional folder path to look for CSV files (defaults to './data')"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    csvContent: z.string().optional(),
    filename: z.string().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const folder = context.folder ? resolve(PROJECT_ROOT, context.folder) : CSV_FOLDER;

    logger?.info(`📂 [fetchLocalCsvTool] Looking for CSV files in: ${folder}`);

    try {
      if (!existsSync(folder)) {
        logger?.error(`❌ [fetchLocalCsvTool] Folder does not exist: ${folder}`);
        return {
          success: false,
          error: `The data folder '${folder}' does not exist. Please create it and upload your CSV file.`,
        };
      }

      const files = readdirSync(folder);
      const csvFiles = files.filter((f) => f.toLowerCase().endsWith(".csv"));

      if (csvFiles.length === 0) {
        logger?.info(`📭 [fetchLocalCsvTool] No CSV files found in ${folder}`);
        return {
          success: false,
          error: `No CSV files found in the '${folder}' folder. Please upload a CSV file.`,
        };
      }

      let mostRecentFile = csvFiles[0];
      let mostRecentTime = 0;

      for (const file of csvFiles) {
        const filePath = join(folder, file);
        const stats = statSync(filePath);
        if (stats.mtimeMs > mostRecentTime) {
          mostRecentTime = stats.mtimeMs;
          mostRecentFile = file;
        }
      }

      const filePath = join(folder, mostRecentFile);
      logger?.info(`📄 [fetchLocalCsvTool] Reading file: ${mostRecentFile}`);

      const csvContent = readFileSync(filePath, "utf-8");

      logger?.info(
        `✅ [fetchLocalCsvTool] Successfully read CSV file (${csvContent.length} chars)`
      );

      return {
        success: true,
        csvContent,
        filename: mostRecentFile,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [fetchLocalCsvTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to read CSV file: ${errorMessage}`,
      };
    }
  },
});
