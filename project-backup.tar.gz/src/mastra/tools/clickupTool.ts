import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { getClickUpClient, getClickUpConfig, getCurrentEnvironment, createTaskDirect, type FieldConfig } from "../../config/clickupEnv";

async function getUncachableClickUpClient() {
  return getClickUpClient();
}

function getFieldMap() {
  return getClickUpConfig().fieldMap;
}

function getApiBaseUrl() {
  return getClickUpConfig().apiBaseUrl;
}

async function getAccessToken() {
  const config = getClickUpConfig();
  return config.getAccessToken();
}

export const createClickUpTaskTool = createTool({
  id: "create-clickup-task",
  description:
    "Creates a task in ClickUp with the provided data. Maps CSV fields to ClickUp task fields and custom fields.",

  inputSchema: z.object({
    listId: z.string().describe("The ClickUp list ID to create the task in"),
    taskData: z.record(z.string()).describe("The task data as key-value pairs from CSV row"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    taskId: z.string().optional(),
    taskName: z.string().optional(),
    taskUrl: z.string().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("✨ [createClickUpTaskTool] Creating ClickUp task...");

    try {
      const clickup = await getUncachableClickUpClient();
      const { listId, taskData } = context;

      const taskName = taskData["Opportunity Name"] || "Untitled Task";
      logger?.info(`📝 [createClickUpTaskTool] Creating task: ${taskName}`);

      const customFields: Array<{ id: string; value: any }> = [];

      logger?.info(`🔧 [createClickUpTaskTool] Mapping ${Object.keys(getFieldMap()).length} custom fields using direct IDs`);

      for (const [csvField, fieldInfo] of Object.entries(getFieldMap())) {
        const value = taskData[csvField];
        if (!value || value.trim() === "") continue;

        let processedValue: any = value;

        if (fieldInfo.type === "date") {
          let dateValue: Date;
          if (value.includes('/')) {
            // DD/MM/YYYY format - parse and set to noon UTC to avoid timezone edge cases
            const parts = value.split('/');
            if (parts.length === 3) {
              const day = parseInt(parts[0], 10);
              const month = parseInt(parts[1], 10) - 1; // JS months are 0-indexed
              const year = parseInt(parts[2], 10);
              // Use Date.UTC to ensure consistent UTC time at noon
              dateValue = new Date(Date.UTC(year, month, day, 12, 0, 0));
            } else {
              logger?.info(`  ⚠ Invalid date for ${csvField}: ${value}`);
              continue;
            }
          } else if (value.includes('-')) {
            // ISO format YYYY-MM-DD - parse and set to noon UTC
            const parts = value.split('-');
            if (parts.length === 3) {
              const year = parseInt(parts[0], 10);
              const month = parseInt(parts[1], 10) - 1;
              const day = parseInt(parts[2], 10);
              dateValue = new Date(Date.UTC(year, month, day, 12, 0, 0));
            } else {
              dateValue = new Date(value);
            }
          } else {
            dateValue = new Date(value);
          }
          if (!isNaN(dateValue.getTime())) {
            processedValue = dateValue.getTime();
            logger?.info(`  📅 Date: ${csvField} = "${value}" → ${dateValue.toISOString()} (${processedValue})`);
          } else {
            logger?.info(`  ⚠ Invalid date for ${csvField}: ${value}`);
            continue;
          }
        } else if (fieldInfo.type === "number" || fieldInfo.type === "currency") {
          const numValue = parseFloat(value.replace(/[^0-9.-]/g, ""));
          if (!isNaN(numValue)) {
            processedValue = numValue;
          } else {
            logger?.info(`  ⚠ Invalid number for ${csvField}: ${value}`);
            continue;
          }
        } else if (fieldInfo.type === "checkbox") {
          processedValue = value.toLowerCase() === "true" || value === "1" || value.toLowerCase() === "yes";
        } else if (fieldInfo.type === "url") {
          if (value.startsWith("http://") || value.startsWith("https://")) {
            processedValue = value;
          } else {
            logger?.info(`  ⚠ Skipping non-URL value for ${csvField}: ${value.substring(0, 30)}...`);
            continue;
          }
        } else if (fieldInfo.type === "drop_down" && fieldInfo.options) {
          const optionId = fieldInfo.options[value];
          if (optionId) {
            processedValue = optionId;
          } else {
            logger?.info(`  ⚠ No matching option for ${csvField}: ${value}`);
            continue;
          }
        }

        customFields.push({
          id: fieldInfo.id,
          value: processedValue,
        });
        logger?.info(`  ✓ Mapped: ${csvField} → ${fieldInfo.id} (${fieldInfo.type})`);
      }

      const description = buildTaskDescription(taskData);

      logger?.info(`📤 [createClickUpTaskTool] Sending request to ClickUp API...`);
      
      // Log date fields in custom_fields for debugging
      const dateFields = customFields.filter((f: any) => {
        const fieldEntry = Object.entries(getFieldMap()).find(([_, info]: any) => info.id === f.id && info.type === "date");
        return fieldEntry;
      });
      if (dateFields.length > 0) {
        logger?.info(`📅 [createClickUpTaskTool] Date fields being sent: ${JSON.stringify(dateFields)}`);
      }

      const taskPayload: any = {
        name: taskName,
        description,
      };

      if (customFields.length > 0) {
        taskPayload.custom_fields = customFields;
      }

      let task: any;
      try {
        // Use direct API for staging since clickup.js doesn't support custom base URLs
        if (getCurrentEnvironment() === "staging") {
          logger?.info(`🔧 [createClickUpTaskTool] Using direct API for staging environment`);
          task = await createTaskDirect(listId, taskPayload);
        } else {
          const response = await clickup.lists.createTask(listId, taskPayload);
          task = response.body;
        }
      } catch (apiError: any) {
        const errorBody = apiError?.response?.body || apiError?.message;
        logger?.error(`❌ [createClickUpTaskTool] API Error Response: ${JSON.stringify(errorBody)}`);
        throw new Error(typeof errorBody === 'object' ? errorBody?.err || JSON.stringify(errorBody) : errorBody);
      }

      logger?.info(`✅ [createClickUpTaskTool] Task created successfully: ${task.id}`);

      return {
        success: true,
        taskId: task.id,
        taskName: task.name,
        taskUrl: task.url,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [createClickUpTaskTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to create ClickUp task: ${errorMessage}`,
      };
    }
  },
});

// Account list ID for relationship management - from config
function getAccountListId() {
  return getClickUpConfig().accountListId;
}

function getOpportunityListId() {
  return getClickUpConfig().opportunityListId;
}

/**
 * Search for tasks in a ClickUp list by name
 */
export const searchClickUpTasksTool = createTool({
  id: "search-clickup-tasks",
  description: "Searches for tasks in a ClickUp list by name. Returns matching tasks.",

  inputSchema: z.object({
    listId: z.string().describe("The ClickUp list ID to search in"),
    searchQuery: z.string().describe("The task name to search for"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    tasks: z.array(z.object({
      id: z.string(),
      name: z.string(),
      url: z.string().optional(),
    })),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { listId, searchQuery } = context;
    logger?.info(`🔍 [searchClickUpTasksTool] Searching for "${searchQuery}" in list ${listId}`);

    try {
      const token = await getAccessToken();
      
      // Use ClickUp API directly for searching tasks
      const response = await fetch(
        `${getApiBaseUrl()}/api/v2/list/${listId}/task?include_closed=true`,
        {
          headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ClickUp API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      const tasks = data.tasks || [];
      
      // Filter tasks by name (case-insensitive exact match)
      const matchingTasks = tasks.filter((task: any) => 
        task.name.toLowerCase().trim() === searchQuery.toLowerCase().trim()
      );

      logger?.info(`🔍 [searchClickUpTasksTool] Found ${matchingTasks.length} matching task(s) out of ${tasks.length} total`);

      return {
        success: true,
        tasks: matchingTasks.map((task: any) => ({
          id: task.id,
          name: task.name,
          url: task.url,
        })),
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [searchClickUpTasksTool] Error: ${errorMessage}`);
      return {
        success: false,
        tasks: [],
        error: `Failed to search tasks: ${errorMessage}`,
      };
    }
  },
});

/**
 * Create an Account task in ClickUp
 */
export const createAccountTaskTool = createTool({
  id: "create-account-task",
  description: "Creates an Account task in the Accounts list in ClickUp.",

  inputSchema: z.object({
    accountName: z.string().describe("The name of the account to create"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    taskId: z.string().optional(),
    taskName: z.string().optional(),
    taskUrl: z.string().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { accountName } = context;
    logger?.info(`🏢 [createAccountTaskTool] Creating Account task: ${accountName}`);

    try {
      const clickup = await getUncachableClickUpClient();

      const taskPayload = {
        name: accountName,
        description: `## Account\n\n**Account Name:** ${accountName}\n\n*Created automatically from opportunity sync*`,
      };

      let task: any;
      try {
        // Use direct API for staging since clickup.js doesn't support custom base URLs
        if (getCurrentEnvironment() === "staging") {
          logger?.info(`🔧 [createAccountTaskTool] Using direct API for staging environment`);
          task = await createTaskDirect(getAccountListId(), taskPayload);
        } else {
          const response = await clickup.lists.createTask(getAccountListId(), taskPayload);
          task = response.body;
        }
      } catch (apiError: any) {
        const errorBody = apiError?.response?.body || apiError?.message;
        logger?.error(`❌ [createAccountTaskTool] API Error: ${JSON.stringify(errorBody)}`);
        throw new Error(typeof errorBody === 'object' ? errorBody?.err || JSON.stringify(errorBody) : errorBody);
      }
      logger?.info(`✅ [createAccountTaskTool] Account task created: ${task.id}`);

      return {
        success: true,
        taskId: task.id,
        taskName: task.name,
        taskUrl: task.url,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [createAccountTaskTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to create Account task: ${errorMessage}`,
      };
    }
  },
});

/**
 * Create a link/relationship between two ClickUp tasks
 */
export const linkClickUpTasksTool = createTool({
  id: "link-clickup-tasks",
  description: "Creates a relationship link between two ClickUp tasks.",

  inputSchema: z.object({
    taskId: z.string().describe("The ID of the first task"),
    linksToTaskId: z.string().describe("The ID of the task to link to"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { taskId, linksToTaskId } = context;
    logger?.info(`🔗 [linkClickUpTasksTool] Linking task ${taskId} to ${linksToTaskId}`);

    try {
      const token = await getAccessToken();

      const response = await fetch(
        `${getApiBaseUrl()}/api/v2/task/${taskId}/link/${linksToTaskId}`,
        {
          method: 'POST',
          headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ClickUp API error: ${response.status} - ${errorText}`);
      }

      logger?.info(`✅ [linkClickUpTasksTool] Tasks linked successfully`);

      return {
        success: true,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [linkClickUpTasksTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to link tasks: ${errorMessage}`,
      };
    }
  },
});

// Export functions for workflow use
export { getAccountListId, getOpportunityListId, getFieldMap, getApiBaseUrl };

// Export field map for comparison in workflow (dynamically loaded based on environment)
export const CSV_FIELD_MAP = getFieldMap();

/**
 * Update an existing ClickUp task with new data
 */
export const updateClickUpTaskTool = createTool({
  id: "update-clickup-task",
  description: "Updates an existing ClickUp task with new field values from CSV data.",

  inputSchema: z.object({
    taskId: z.string().describe("The ID of the task to update"),
    taskData: z.record(z.string()).describe("The updated task data as key-value pairs from CSV row"),
    existingCustomFields: z.array(z.object({
      id: z.string(),
      value: z.any(),
    })).optional().describe("Existing custom field values from the task"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    taskId: z.string().optional(),
    fieldsUpdated: z.number().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { taskId, taskData, existingCustomFields } = context;
    logger?.info(`📝 [updateClickUpTaskTool] Updating task ${taskId}...`);

    try {
      const token = await getAccessToken();

      // Build custom fields to update
      const customFields: Array<{ id: string; value: any }> = [];

      for (const [csvField, fieldInfo] of Object.entries(getFieldMap())) {
        const value = taskData[csvField];
        if (!value || value.trim() === "") continue;

        let processedValue: any = value;

        if (fieldInfo.type === "date") {
          let dateValue: Date;
          if (value.includes('/')) {
            const parts = value.split('/');
            if (parts.length === 3) {
              const day = parseInt(parts[0], 10);
              const month = parseInt(parts[1], 10) - 1;
              const year = parseInt(parts[2], 10);
              dateValue = new Date(Date.UTC(year, month, day, 12, 0, 0));
            } else {
              continue;
            }
          } else if (value.includes('-')) {
            const parts = value.split('-');
            if (parts.length === 3) {
              const year = parseInt(parts[0], 10);
              const month = parseInt(parts[1], 10) - 1;
              const day = parseInt(parts[2], 10);
              dateValue = new Date(Date.UTC(year, month, day, 12, 0, 0));
            } else {
              dateValue = new Date(value);
            }
          } else {
            dateValue = new Date(value);
          }
          if (!isNaN(dateValue.getTime())) {
            processedValue = dateValue.getTime();
          } else {
            continue;
          }
        } else if (fieldInfo.type === "number" || fieldInfo.type === "currency") {
          const numValue = parseFloat(value.replace(/[^0-9.-]/g, ""));
          if (!isNaN(numValue)) {
            processedValue = numValue;
          } else {
            continue;
          }
        } else if (fieldInfo.type === "checkbox") {
          processedValue = value.toLowerCase() === "true" || value === "1" || value.toLowerCase() === "yes";
        } else if (fieldInfo.type === "url") {
          if (value.startsWith("http://") || value.startsWith("https://")) {
            processedValue = value;
          } else {
            continue;
          }
        } else if (fieldInfo.type === "drop_down" && fieldInfo.options) {
          const optionId = fieldInfo.options[value];
          if (optionId) {
            processedValue = optionId;
          } else {
            continue;
          }
        }

        customFields.push({
          id: fieldInfo.id,
          value: processedValue,
        });
      }

      // Update task name if Opportunity Name changed
      const taskName = taskData["Opportunity Name"];
      let nameUpdated = false;

      if (taskName) {
        const nameResponse = await fetch(
          `${getApiBaseUrl()}/api/v2/task/${taskId}`,
          {
            method: 'PUT',
            headers: {
              'Authorization': token,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              name: taskName,
              description: buildTaskDescription(taskData),
            }),
          }
        );

        if (nameResponse.ok) {
          nameUpdated = true;
          logger?.info(`✅ [updateClickUpTaskTool] Updated task name and description`);
        }
      }

      // Update each custom field individually
      let fieldsUpdated = 0;
      for (const field of customFields) {
        try {
          const fieldResponse = await fetch(
            `${getApiBaseUrl()}/api/v2/task/${taskId}/field/${field.id}`,
            {
              method: 'POST',
              headers: {
                'Authorization': token,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ value: field.value }),
            }
          );

          if (fieldResponse.ok) {
            fieldsUpdated++;
          } else {
            const errorText = await fieldResponse.text();
            logger?.warn(`⚠️ [updateClickUpTaskTool] Failed to update field ${field.id}: ${errorText}`);
          }
        } catch (fieldError) {
          logger?.warn(`⚠️ [updateClickUpTaskTool] Error updating field ${field.id}: ${fieldError}`);
        }
      }

      logger?.info(`✅ [updateClickUpTaskTool] Updated ${fieldsUpdated} custom fields`);

      return {
        success: true,
        taskId,
        fieldsUpdated,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [updateClickUpTaskTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to update ClickUp task: ${errorMessage}`,
      };
    }
  },
});

/**
 * Get a ClickUp task by ID with all custom fields
 */
export const getClickUpTaskTool = createTool({
  id: "get-clickup-task",
  description: "Fetches a ClickUp task by ID with all its custom fields.",

  inputSchema: z.object({
    taskId: z.string().describe("The ID of the task to fetch"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    task: z.object({
      id: z.string(),
      name: z.string(),
      customFields: z.array(z.object({
        id: z.string(),
        name: z.string(),
        value: z.any(),
      })),
    }).optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { taskId } = context;
    logger?.info(`📋 [getClickUpTaskTool] Fetching task ${taskId}...`);

    try {
      const token = await getAccessToken();

      const response = await fetch(
        `${getApiBaseUrl()}/api/v2/task/${taskId}`,
        {
          headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ClickUp API error: ${response.status} - ${errorText}`);
      }

      const task = await response.json();

      return {
        success: true,
        task: {
          id: task.id,
          name: task.name,
          customFields: (task.custom_fields || []).map((cf: any) => ({
            id: cf.id,
            name: cf.name,
            value: cf.value,
          })),
        },
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [getClickUpTaskTool] Error: ${errorMessage}`);
      return {
        success: false,
        error: `Failed to fetch task: ${errorMessage}`,
      };
    }
  },
});

/**
 * Search for opportunities by Opportunity ID custom field
 */
export const searchOpportunityByIdTool = createTool({
  id: "search-opportunity-by-id",
  description: "Searches for an opportunity task by its Opportunity ID custom field value.",

  inputSchema: z.object({
    listId: z.string().describe("The ClickUp list ID to search in"),
    opportunityId: z.string().describe("The Opportunity ID to search for"),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    found: z.boolean(),
    task: z.object({
      id: z.string(),
      name: z.string(),
      customFields: z.array(z.object({
        id: z.string(),
        name: z.string(),
        value: z.any(),
      })),
    }).optional(),
    error: z.string().optional(),
  }),

  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { listId, opportunityId } = context;
    logger?.info(`🔍 [searchOpportunityByIdTool] Searching for Opportunity ID "${opportunityId}" in list ${listId}`);

    try {
      const token = await getAccessToken();

      // Get the Opportunity ID field ID
      const opportunityIdFieldId = getFieldMap()["Opportunity ID"]?.id;
      if (!opportunityIdFieldId) {
        throw new Error("Opportunity ID field not configured");
      }

      // Fetch all tasks from the list with custom fields
      // ClickUp API supports filtering by custom field values
      const url = `${getApiBaseUrl()}/api/v2/list/${listId}/task?include_closed=true&custom_fields=[{"field_id":"${opportunityIdFieldId}","operator":"=","value":"${opportunityId}"}]`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': token,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        // Fallback: If custom field filtering not supported, fetch all pages and filter manually
        logger?.info(`🔍 [searchOpportunityByIdTool] Custom field filter not supported, falling back to manual search...`);
        
        let allTasks: any[] = [];
        let page = 0;
        while (true) {
          const allTasksResponse = await fetch(
            `${getApiBaseUrl()}/api/v2/list/${listId}/task?include_closed=true&page=${page}`,
            {
              headers: {
                'Authorization': token,
                'Content-Type': 'application/json',
              },
            }
          );

          if (!allTasksResponse.ok) {
            const errorText = await allTasksResponse.text();
            throw new Error(`ClickUp API error: ${allTasksResponse.status} - ${errorText}`);
          }

          const allTasksData = await allTasksResponse.json();
          const pageTasks = allTasksData.tasks || [];
          if (pageTasks.length === 0) break;
          allTasks = allTasks.concat(pageTasks);
          page++;
        }

        // Find task with matching Opportunity ID
        const matchingTask = allTasks.find((task: any) => {
          const customFields = task.custom_fields || [];
          const oppIdField = customFields.find((cf: any) => cf.id === opportunityIdFieldId);
          return oppIdField && oppIdField.value === opportunityId;
        });

        if (matchingTask) {
          logger?.info(`✅ [searchOpportunityByIdTool] Found matching task: ${matchingTask.id}`);
          return {
            success: true,
            found: true,
            task: {
              id: matchingTask.id,
              name: matchingTask.name,
              customFields: (matchingTask.custom_fields || []).map((cf: any) => ({
                id: cf.id,
                name: cf.name,
                value: cf.value,
              })),
            },
          };
        }

        logger?.info(`🔍 [searchOpportunityByIdTool] No matching task found for Opportunity ID "${opportunityId}"`);
        return {
          success: true,
          found: false,
        };
      }

      const data = await response.json();
      const tasks = data.tasks || [];

      if (tasks.length > 0) {
        const task = tasks[0];
        logger?.info(`✅ [searchOpportunityByIdTool] Found matching task: ${task.id}`);
        return {
          success: true,
          found: true,
          task: {
            id: task.id,
            name: task.name,
            customFields: (task.custom_fields || []).map((cf: any) => ({
              id: cf.id,
              name: cf.name,
              value: cf.value,
            })),
          },
        };
      }

      logger?.info(`🔍 [searchOpportunityByIdTool] No matching task found for Opportunity ID "${opportunityId}"`);
      return {
        success: true,
        found: false,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error(`❌ [searchOpportunityByIdTool] Error: ${errorMessage}`);
      return {
        success: false,
        found: false,
        error: `Failed to search for opportunity: ${errorMessage}`,
      };
    }
  },
});

function buildTaskDescription(taskData: Record<string, string>): string {
  const sections: string[] = [];

  sections.push("## Opportunity Details\n");

  const fieldGroups = [
    {
      title: "Basic Info",
      fields: ["Opportunity ID", "Account Name", "Sales Estimated Quota Relief", "Forecast Category"],
    },
    {
      title: "Stage & Timeline",
      fields: ["Stage", "Close Date", "Next Step Date", "Next Step", "Created Date"],
    },
    {
      title: "MEDDPICC",
      fields: [
        "Metrics",
        "Economic Buyer",
        "Decision Criteria",
        "Decision Process",
        "Paper Process",
        "Implicated Pain",
        "Champion Name",
        "Competitor",
        "Other Competitor",
      ],
    },
    {
      title: "Progress Checkpoints",
      fields: [
        "CUO Meeting Completed",
        "Evaluation Agreed",
        "Pricing Discussed",
        "Decision Criteria Met",
        "Economic Buyer Approved",
        "Ironclad Signatory",
      ],
    },
    {
      title: "Additional",
      fields: ["Mutual Action Plan (MAP) URL", "3 Whys Business Case"],
    },
  ];

  for (const group of fieldGroups) {
    const groupFields: string[] = [];
    for (const field of group.fields) {
      const value = taskData[field];
      if (value && value.trim() !== "") {
        groupFields.push(`**${field}:** ${value}`);
      }
    }
    if (groupFields.length > 0) {
      sections.push(`### ${group.title}\n${groupFields.join("\n")}\n`);
    }
  }

  return sections.join("\n");
}
