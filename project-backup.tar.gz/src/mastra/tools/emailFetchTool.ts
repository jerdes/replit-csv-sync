import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import Imap from "imap";
import { simpleParser, ParsedMail } from "mailparser";
import * as fs from "fs";
import * as path from "path";

// Use absolute path to workspace to ensure files are saved to project data folder
const WORKSPACE_ROOT = "/home/runner/workspace";
const DATA_DIR = path.join(WORKSPACE_ROOT, "data");
const DEFAULT_LABEL = "salesforce-report";

interface FetchOptions {
  daysBack?: number;
  labelName?: string;
}

async function fetchEmailWithIMAP(options: FetchOptions = {}): Promise<{ 
  success: boolean; 
  filename?: string; 
  emailSubject?: string;
  emailDate?: string;
  error?: string 
}> {
  const { daysBack = 2, labelName = DEFAULT_LABEL } = options;
  
  return new Promise((resolve) => {
    const imapConfig: Imap.Config = {
      user: process.env.GMAIL_USER_EMAIL || "",
      password: process.env.GMAIL_APP_PASSWORD || "",
      host: "imap.gmail.com",
      port: 993,
      tls: true,
      tlsOptions: { rejectUnauthorized: false },
    };

    if (!imapConfig.user || !imapConfig.password) {
      resolve({ success: false, error: "GMAIL_USER_EMAIL or GMAIL_APP_PASSWORD not configured" });
      return;
    }

    console.log(`📧 Connecting to Gmail as ${imapConfig.user}...`);
    const imap = new Imap(imapConfig);

    imap.once("ready", () => {
      console.log("✅ Connected to Gmail");
      
      const mailboxName = labelName;
      
      imap.openBox(mailboxName, true, (err, box) => {
        if (err) {
          console.log(`⚠️ Label "${labelName}" not found, falling back to INBOX...`);
          imap.openBox("INBOX", true, (err2, box2) => {
            if (err2) {
              resolve({ success: false, error: `Failed to open mailbox: ${err2.message}` });
              imap.end();
              return;
            }
            searchAndFetch(imap, box2, daysBack, null, resolve);
          });
          return;
        }

        console.log(`📬 Opened label "${labelName}" with ${box.messages.total} messages`);
        searchAndFetch(imap, box, daysBack, labelName, resolve);
      });
    });

    imap.once("error", (err: Error) => {
      resolve({ success: false, error: `IMAP connection error: ${err.message}` });
    });

    imap.connect();
  });
}

function searchAndFetch(
  imap: Imap, 
  box: Imap.Box, 
  daysBack: number, 
  labelName: string | null,
  resolve: (result: { success: boolean; filename?: string; emailSubject?: string; emailDate?: string; error?: string }) => void
) {
  const sinceDate = new Date();
  sinceDate.setDate(sinceDate.getDate() - daysBack);
  
  imap.search([["SINCE", sinceDate]], (err, results) => {
    if (err) {
      resolve({ success: false, error: `Search failed: ${err.message}` });
      imap.end();
      return;
    }

    console.log(`🔍 Found ${results.length} emails from last ${daysBack} days${labelName ? ` in "${labelName}"` : ""}`);

    if (!results || results.length === 0) {
      resolve({ success: false, error: `No recent emails found${labelName ? ` in label "${labelName}"` : ""}` });
      imap.end();
      return;
    }

    const emailsToCheck = results.slice(-10);
    console.log(`📋 Checking last ${emailsToCheck.length} emails for CSV attachments...`);
    
    const fetch = imap.fetch(emailsToCheck, { bodies: "", struct: true });

    let foundCsv = false;
    let savedFilename = "";
    let latestCsvDate: Date | null = null;
    let latestSubject = "";
    
    const messagePromises: Promise<void>[] = [];

    fetch.on("message", (msg, seqno) => {
      let buffer = "";

      msg.on("body", (stream, info) => {
        stream.on("data", (chunk) => {
          buffer += chunk.toString("utf8");
        });
      });

      const messagePromise = new Promise<void>((resolveMsg) => {
        msg.once("end", async () => {
          try {
            const parsed: ParsedMail = await simpleParser(buffer);
            const subject = parsed.subject || "";
            const emailDate = parsed.date || new Date(0);
            
            if (parsed.attachments && parsed.attachments.length > 0) {
              for (const attachment of parsed.attachments) {
                if (attachment.filename && 
                    (attachment.filename.endsWith(".csv") || 
                     attachment.contentType === "text/csv")) {
                  
                  if (!latestCsvDate || emailDate > latestCsvDate) {
                    if (!fs.existsSync(DATA_DIR)) {
                      fs.mkdirSync(DATA_DIR, { recursive: true });
                    }

                    const timestamp = new Date().toISOString().split("T")[0];
                    savedFilename = `opportunities_${timestamp}.csv`;
                    const filepath = path.join(DATA_DIR, savedFilename);

                    console.log(`💾 Saving CSV to: ${filepath}`);
                    fs.writeFileSync(filepath, attachment.content);
                    foundCsv = true;
                    latestCsvDate = emailDate;
                    latestSubject = subject;
                    console.log(`📧 Found CSV: ${attachment.filename}`);
                    console.log(`   From email: "${subject.substring(0, 60)}"`);
                    console.log(`   Date: ${emailDate.toISOString()}`);
                    console.log(`   Saved as: ${savedFilename}`);
                  }
                }
              }
            }
          } catch (parseErr: any) {
            console.error("Failed to parse email:", parseErr.message);
          }
          resolveMsg();
        });
      });
      messagePromises.push(messagePromise);
    });

    fetch.once("error", (err) => {
      resolve({ success: false, error: `Fetch error: ${err.message}` });
    });

    fetch.once("end", async () => {
      await Promise.all(messagePromises);
      imap.end();
      if (foundCsv && latestCsvDate) {
        console.log(`✅ CSV saved successfully: ${savedFilename}`);
        resolve({ 
          success: true, 
          filename: savedFilename,
          emailSubject: latestSubject,
          emailDate: latestCsvDate.toISOString(),
        });
      } else {
        console.log(`⚠️ No CSV attachments found${labelName ? ` in label "${labelName}"` : ""}`);
        resolve({ success: false, error: `No CSV attachment found${labelName ? ` in label "${labelName}"` : ""}` });
      }
    });
  });
}

export const fetchEmailCsvTool = createTool({
  id: "fetch-email-csv",
  description: "Fetches the latest CSV attachment from a Gmail label via IMAP. Searches the specified label folder for emails with CSV attachments.",
  inputSchema: z.object({
    labelName: z.string().optional().default(DEFAULT_LABEL).describe("Gmail label to search (default: 'salesforce-report')"),
    daysBack: z.number().optional().default(2).describe("How many days back to search for emails"),
  }),
  outputSchema: z.object({
    success: z.boolean(),
    filename: z.string().optional(),
    filepath: z.string().optional(),
    emailSubject: z.string().optional(),
    emailDate: z.string().optional(),
    error: z.string().optional(),
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info(`📧 [fetchEmailCsv] Starting email fetch from label "${context.labelName || DEFAULT_LABEL}"...`);

    try {
      const result = await fetchEmailWithIMAP({
        daysBack: context.daysBack || 2,
        labelName: context.labelName || DEFAULT_LABEL,
      });

      if (result.success && result.filename) {
        const filepath = path.join(DATA_DIR, result.filename);
        logger?.info(`✅ [fetchEmailCsv] Downloaded: ${result.filename} from "${result.emailSubject}"`);
        return {
          success: true,
          filename: result.filename,
          filepath: filepath,
          emailSubject: result.emailSubject,
          emailDate: result.emailDate,
        };
      } else {
        logger?.warn(`⚠️ [fetchEmailCsv] Failed: ${result.error}`);
        return {
          success: false,
          error: result.error,
        };
      }
    } catch (error: any) {
      logger?.error(`❌ [fetchEmailCsv] Error: ${error.message}`);
      return {
        success: false,
        error: error.message,
      };
    }
  },
});
