import { Agent } from "@mastra/core/agent";
import { createOpenAI } from "@ai-sdk/openai";
import { fetchLocalCsvTool } from "../tools/localCsvTool";
import { parseCsvTool } from "../tools/csvParseTool";
import { createClickUpTaskTool } from "../tools/clickupTool";

const openai = createOpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export const csvSyncAgent = new Agent({
  name: "CSV to ClickUp Sync Agent",

  instructions: `
    You are a data synchronization agent that helps sync CSV data from a local file to ClickUp tasks.
    
    Your responsibilities:
    1. Fetch the most recent CSV file from the data folder
    2. Parse the CSV data into structured records
    3. Create ClickUp tasks for each row in the CSV
    
    When processing data:
    - Always validate that data was successfully retrieved before proceeding
    - Report any errors clearly with specific details
    - Track how many tasks were successfully created vs failed
    - Provide a summary of the sync operation when complete
    
    The CSV contains sales opportunity data with the following fields:
    - Opportunity ID, Account Name, Opportunity Name
    - Sales Estimated Quota Relief, Stage, Close Date
    - Next Step Date, Next Step
    - MEDDPICC fields: Metrics, Economic Buyer, Decision Criteria, Decision Process, Paper Process, Implicated Pain, Champion Name, Competitor, Other Competitor
    - Progress checkpoints: CUO Meeting Completed, Evaluation Agreed, Pricing Discussed, Decision Criteria Met, Economic Buyer Approved, Ironclad Signatory
    - Additional: Mutual Action Plan URL, 3 Whys Business Case, Forecast Category, Created Date
    
    The target ClickUp list ID is: 901612392243
    
    Be efficient and process all records systematically.
  `,

  model: openai("gpt-4o"),

  tools: {
    fetchLocalCsvTool,
    parseCsvTool,
    createClickUpTaskTool,
  },
});
