import { createStep, createWorkflow } from "../inngest";
import { z } from "zod";
import { fetchLocalCsvTool } from "../tools/localCsvTool";
import { parseCsvTool } from "../tools/csvParseTool";
import { fetchEmailCsvTool } from "../tools/emailFetchTool";
import { 
  createClickUpTaskTool, 
  searchClickUpTasksTool, 
  createAccountTaskTool, 
  linkClickUpTasksTool,
  updateClickUpTaskTool,
  searchOpportunityByIdTool,
  getAccountListId,
  getOpportunityListId,
  CSV_FIELD_MAP
} from "../tools/clickupTool";
import { getCurrentEnvironment, getClickUpConfig } from "../../config/clickupEnv";

// Cache for existing opportunities by Opportunity ID
interface OpportunityCache {
  taskId: string;
  name: string;
  customFields: Array<{ id: string; name: string; value: any }>;
}
const opportunityCache: Map<string, OpportunityCache> = new Map();

const fetchEmailCsv = createStep({
  id: "fetch-email-csv",
  description: "Fetches the latest CSV attachment from email via IMAP",

  inputSchema: z.object({}),

  outputSchema: z.object({
    success: z.boolean(),
    filename: z.string().optional(),
    filepath: z.string().optional(),
    error: z.string().optional(),
    skipped: z.boolean().optional(),
  }),

  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📧 [Step 0] Checking for CSV in email...");

    const hasEmailConfig = process.env.GMAIL_USER_EMAIL && process.env.GMAIL_APP_PASSWORD;
    
    if (!hasEmailConfig) {
      logger?.info("📧 [Step 0] Email not configured, skipping email fetch...");
      return {
        success: true,
        skipped: true,
        error: "Email credentials not configured - using local CSV files",
      };
    }

    const result = await fetchEmailCsvTool.execute({
      context: { daysBack: 2, labelName: "salesforce-report" },
      mastra,
      runtimeContext: {} as any,
    });

    if (!result.success) {
      logger?.warn(`⚠️ [Step 0] Email fetch failed: ${result.error} - will try local CSV`);
    } else {
      logger?.info(`✅ [Step 0] Downloaded CSV from email: ${result.filename}`);
    }

    return result;
  },
});

const fetchCsvFile = createStep({
  id: "fetch-csv-file",
  description: "Fetches the most recent CSV file from the data folder",

  inputSchema: z.object({}),

  outputSchema: z.object({
    success: z.boolean(),
    csvContent: z.string().optional(),
    filename: z.string().optional(),
    error: z.string().optional(),
  }),

  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📂 [Step 1] Fetching CSV file from data folder...");

    const result = await fetchLocalCsvTool.execute({
      context: { folder: "./data" },
      mastra,
      runtimeContext: {} as any,
    });

    if (!result.success) {
      logger?.error(`❌ [Step 1] Failed to fetch CSV: ${result.error}`);
    } else {
      logger?.info(`✅ [Step 1] Successfully fetched CSV: ${result.filename}`);
    }

    return result;
  },
});

const parseCsvData = createStep({
  id: "parse-csv-data",
  description: "Parses the CSV file into structured data",

  inputSchema: z.object({
    success: z.boolean(),
    csvContent: z.string().optional(),
    filename: z.string().optional(),
    error: z.string().optional(),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    rows: z.array(z.record(z.string())).optional(),
    rowCount: z.number().optional(),
    columns: z.array(z.string()).optional(),
    error: z.string().optional(),
    fileInfo: z
      .object({
        filename: z.string().optional(),
      })
      .optional(),
  }),

  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📊 [Step 2] Parsing CSV data...");

    if (!inputData.success || !inputData.csvContent) {
      logger?.error(`❌ [Step 2] No CSV content to parse: ${inputData.error}`);
      return {
        success: false,
        error: inputData.error || "No CSV content available",
      };
    }

    const result = await parseCsvTool.execute({
      context: { csvContent: inputData.csvContent },
      mastra,
      runtimeContext: {} as any,
    });

    if (!result.success) {
      logger?.error(`❌ [Step 2] Failed to parse CSV: ${result.error}`);
    } else {
      logger?.info(`✅ [Step 2] Successfully parsed ${result.rowCount} rows`);
    }

    return {
      ...result,
      fileInfo: {
        filename: inputData.filename,
      },
    };
  },
});

const createClickUpTask = createStep({
  id: "create-clickup-task",
  description: "Creates a ClickUp task for a single CSV row",

  inputSchema: z.object({
    taskData: z.record(z.string()),
    rowIndex: z.number(),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    taskId: z.string().optional(),
    taskName: z.string().optional(),
    taskUrl: z.string().optional(),
    error: z.string().optional(),
    rowIndex: z.number(),
  }),

  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const taskName = inputData.taskData["Opportunity Name"] || "Unknown";
    logger?.info(`✨ [Task ${inputData.rowIndex + 1}] Creating task: ${taskName}`);

    const result = await createClickUpTaskTool.execute({
      context: {
        listId: getOpportunityListId(),
        taskData: inputData.taskData,
      },
      mastra,
      runtimeContext: {} as any,
    });

    if (!result.success) {
      logger?.error(`❌ [Task ${inputData.rowIndex + 1}] Failed: ${result.error}`);
    } else {
      logger?.info(`✅ [Task ${inputData.rowIndex + 1}] Created: ${result.taskId}`);
    }

    return {
      ...result,
      rowIndex: inputData.rowIndex,
    };
  },
});

// Cache for Account tasks to avoid repeated API calls
const accountCache: Map<string, string> = new Map();

// Helper function to compare CSV value with ClickUp custom field value
function compareFieldValues(csvValue: string, clickUpValue: any, fieldType: string, fieldOptions?: Record<string, string>): boolean {
  if (!csvValue || csvValue.trim() === "") {
    // Empty CSV value means no update needed (we don't clear fields)
    return true;
  }

  switch (fieldType) {
    case "short_text":
    case "text":
      if (clickUpValue === null || clickUpValue === undefined) {
        return false;
      }
      return String(csvValue).trim() === String(clickUpValue).trim();
    
    case "currency":
    case "number":
      const csvNum = parseFloat(String(csvValue).replace(/[^0-9.-]/g, ""));
      const clickUpNum = parseFloat(String(clickUpValue || 0));
      if (isNaN(csvNum)) return true; // Invalid CSV value, skip
      return !isNaN(clickUpNum) && csvNum === clickUpNum;
    
    case "date":
      if (clickUpValue === null || clickUpValue === undefined) {
        return false;
      }
      // Parse CSV date and compare with ClickUp timestamp
      let csvTimestamp: number;
      if (csvValue.includes('/')) {
        const parts = csvValue.split('/');
        if (parts.length === 3) {
          const day = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10) - 1;
          const year = parseInt(parts[2], 10);
          csvTimestamp = Date.UTC(year, month, day, 12, 0, 0);
        } else {
          return true; // Invalid date format, skip comparison
        }
      } else if (csvValue.includes('-')) {
        const parts = csvValue.split('-');
        if (parts.length === 3) {
          const year = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10) - 1;
          const day = parseInt(parts[2], 10);
          csvTimestamp = Date.UTC(year, month, day, 12, 0, 0);
        } else {
          return true;
        }
      } else {
        return true;
      }
      // Compare dates at day level (ignore time differences)
      const csvDate = new Date(csvTimestamp);
      const clickUpDate = new Date(Number(clickUpValue));
      return csvDate.toISOString().split('T')[0] === clickUpDate.toISOString().split('T')[0];
    
    case "checkbox":
      // CSV "0", "false", "no", "" = false; "1", "true", "yes" = true
      const csvBool = csvValue.toLowerCase() === "true" || csvValue === "1" || csvValue.toLowerCase() === "yes";
      // ClickUp: undefined/null/false = false; true/"true"/1/"1" = true
      const clickUpBool = clickUpValue === true || clickUpValue === "true" || clickUpValue === 1 || clickUpValue === "1";
      return csvBool === clickUpBool;
    
    case "drop_down":
      // ClickUp returns dropdown values as the selected option's index (0, 1, 2, ...)
      // We need to find what index the CSV value would map to
      if (fieldOptions) {
        const csvOptionId = fieldOptions[csvValue];
        if (!csvOptionId) return true; // No matching option, skip comparison
        
        // ClickUp value is the index of the selected option
        // Since we don't have the full options list here, we'll need to accept
        // that the comparison will trigger updates. The update will set correct values.
        // For now, just compare option IDs if ClickUp returns them
        if (typeof clickUpValue === 'string' && clickUpValue.startsWith('opt_')) {
          return csvOptionId === clickUpValue;
        }
        // ClickUp returned an index - we can't reliably compare without full options
        // Skip comparison to avoid false positives
        return true;
      }
      return true;
    
    case "url":
      if (clickUpValue === null || clickUpValue === undefined) {
        return false;
      }
      return String(csvValue).trim() === String(clickUpValue).trim();
    
    default:
      if (clickUpValue === null || clickUpValue === undefined) {
        return false;
      }
      return String(csvValue).trim() === String(clickUpValue).trim();
  }
}

const processAllRows = createStep({
  id: "process-all-rows",
  description: "Processes all CSV rows - creates new tasks or updates existing ones based on Opportunity ID",

  inputSchema: z.object({
    success: z.boolean(),
    rows: z.array(z.record(z.string())).optional(),
    rowCount: z.number().optional(),
    columns: z.array(z.string()).optional(),
    error: z.string().optional(),
    fileInfo: z
      .object({
        filename: z.string().optional(),
      })
      .optional(),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    totalRows: z.number(),
    createdCount: z.number(),
    updatedCount: z.number(),
    skippedCount: z.number(),
    failureCount: z.number(),
    accountsCreated: z.number(),
    accountsLinked: z.number(),
    results: z.array(
      z.object({
        rowIndex: z.number(),
        action: z.enum(["created", "updated", "skipped", "failed"]),
        taskId: z.string().optional(),
        taskName: z.string().optional(),
        accountId: z.string().optional(),
        accountLinked: z.boolean().optional(),
        fieldsUpdated: z.number().optional(),
        error: z.string().optional(),
      })
    ),
    summary: z.string(),
  }),

  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("🔄 [Step 3] Processing CSV rows with upsert logic (Opportunity ID as unique key)...");

    if (!inputData.success || !inputData.rows || inputData.rows.length === 0) {
      logger?.error(`❌ [Step 3] No rows to process: ${inputData.error}`);
      return {
        success: false,
        totalRows: 0,
        createdCount: 0,
        updatedCount: 0,
        skippedCount: 0,
        failureCount: 0,
        accountsCreated: 0,
        accountsLinked: 0,
        results: [],
        summary: `Failed to process: ${inputData.error || "No data available"}`,
      };
    }

    const rows = inputData.rows;
    const results: Array<{
      rowIndex: number;
      action: "created" | "updated" | "skipped" | "failed";
      taskId?: string;
      taskName?: string;
      accountId?: string;
      accountLinked?: boolean;
      fieldsUpdated?: number;
      error?: string;
    }> = [];

    let createdCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;
    let failureCount = 0;
    let accountsCreated = 0;
    let accountsLinked = 0;

    // Clear caches at start of each workflow run
    accountCache.clear();
    opportunityCache.clear();

    const token = await getAccessTokenForWorkflow();

    // Pre-fetch all existing opportunities with their custom fields (with pagination)
    logger?.info("📂 [Step 3] Fetching existing opportunities from ClickUp...");
    try {
      const opportunityIdFieldId = CSV_FIELD_MAP["Opportunity ID"]?.id;
      let oppPage = 0;
      let hasMoreOpps = true;
      while (hasMoreOpps) {
        const opportunitiesResponse = await fetch(
          `${getClickUpConfig().apiBaseUrl}/api/v2/list/${getOpportunityListId()}/task?include_closed=true&page=${oppPage}`,
          {
            headers: {
              'Authorization': token,
              'Content-Type': 'application/json',
            },
          }
        );
        
        if (opportunitiesResponse.ok) {
          const opportunitiesData = await opportunitiesResponse.json();
          const opportunityTasks = opportunitiesData.tasks || [];
          
          if (opportunityTasks.length === 0) {
            hasMoreOpps = false;
            break;
          }
          
          for (const task of opportunityTasks) {
            const customFields = task.custom_fields || [];
            const oppIdField = customFields.find((cf: any) => cf.id === opportunityIdFieldId);
            if (oppIdField && oppIdField.value) {
              opportunityCache.set(oppIdField.value, {
                taskId: task.id,
                name: task.name,
                customFields: customFields.map((cf: any) => ({
                  id: cf.id,
                  name: cf.name,
                  value: cf.value,
                })),
              });
            }
          }
          logger?.info(`📂 [Step 3] Fetched page ${oppPage}: ${opportunityTasks.length} tasks (total cached: ${opportunityCache.size})`);
          oppPage++;
        } else {
          hasMoreOpps = false;
        }
      }
      logger?.info(`📂 [Step 3] Cached ${opportunityCache.size} existing opportunities by Opportunity ID`);
    } catch (error) {
      logger?.warn(`⚠️ [Step 3] Could not pre-fetch opportunities: ${error}`);
    }

    // Pre-fetch all existing accounts (with pagination)
    logger?.info("📂 [Step 3] Fetching existing accounts from Account list...");
    try {
      let acctPage = 0;
      let hasMoreAccts = true;
      while (hasMoreAccts) {
        const accountsResponse = await fetch(
          `${getClickUpConfig().apiBaseUrl}/api/v2/list/${getAccountListId()}/task?include_closed=true&page=${acctPage}`,
          {
            headers: {
              'Authorization': token,
              'Content-Type': 'application/json',
            },
          }
        );
        
        if (accountsResponse.ok) {
          const accountsData = await accountsResponse.json();
          const accountTasks = accountsData.tasks || [];
          
          if (accountTasks.length === 0) {
            hasMoreAccts = false;
            break;
          }
          
          for (const task of accountTasks) {
            accountCache.set(task.name.toLowerCase().trim(), task.id);
          }
          logger?.info(`📂 [Step 3] Fetched accounts page ${acctPage}: ${accountTasks.length} tasks (total cached: ${accountCache.size})`);
          acctPage++;
        } else {
          hasMoreAccts = false;
        }
      }
      logger?.info(`📂 [Step 3] Cached ${accountCache.size} existing accounts`);
    } catch (error) {
      logger?.warn(`⚠️ [Step 3] Could not pre-fetch accounts: ${error}`);
    }

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const taskName = row["Opportunity Name"] || "Unknown";
      const opportunityId = row["Opportunity ID"]?.trim() || "";
      const accountName = row["Account Name"]?.trim() || "";

      logger?.info(`📝 [Step 3] Processing row ${i + 1}/${rows.length}: ${taskName} (Opp ID: ${opportunityId})`);

      if (!opportunityId) {
        failureCount++;
        results.push({
          rowIndex: i,
          action: "failed",
          taskName,
          error: "Missing Opportunity ID - required for upsert",
        });
        logger?.error(`❌ [Step 3] Row ${i + 1}: Missing Opportunity ID`);
        continue;
      }

      try {
        let opportunityTaskId: string | undefined;
        let action: "created" | "updated" | "skipped" = "created";
        let fieldsUpdated = 0;

        // Check if opportunity already exists
        const existingOpp = opportunityCache.get(opportunityId);

        if (existingOpp) {
          // Opportunity exists - compare fields and update if different
          logger?.info(`🔍 [Step 3] Row ${i + 1}: Found existing opportunity (${existingOpp.taskId})`);
          
          // Compare each field to see if update is needed
          let needsUpdate = false;
          const existingFieldsMap = new Map(existingOpp.customFields.map(cf => [cf.id, cf.value]));

          for (const [csvField, fieldConfig] of Object.entries(CSV_FIELD_MAP)) {
            const csvValue = row[csvField];
            if (!csvValue || csvValue.trim() === "") continue;

            const clickUpValue = existingFieldsMap.get(fieldConfig.id);
            const isEqual = compareFieldValues(csvValue, clickUpValue, fieldConfig.type, fieldConfig.options);
            
            if (!isEqual) {
              needsUpdate = true;
              logger?.info(`  📝 Field "${csvField}" differs: CSV="${csvValue}" vs ClickUp="${clickUpValue}"`);
            }
          }

          // Also check task name
          if (taskName !== existingOpp.name) {
            needsUpdate = true;
            logger?.info(`  📝 Task name differs: CSV="${taskName}" vs ClickUp="${existingOpp.name}"`);
          }

          if (needsUpdate) {
            logger?.info(`🔄 [Step 3] Row ${i + 1}: Updating opportunity...`);
            const updateResult = await updateClickUpTaskTool.execute({
              context: {
                taskId: existingOpp.taskId,
                taskData: row,
              },
              mastra,
              runtimeContext: {} as any,
            });

            if (updateResult.success) {
              action = "updated";
              updatedCount++;
              fieldsUpdated = updateResult.fieldsUpdated || 0;
              opportunityTaskId = existingOpp.taskId;
              logger?.info(`✅ [Step 3] Row ${i + 1}: Updated ${fieldsUpdated} fields`);
            } else {
              failureCount++;
              results.push({
                rowIndex: i,
                action: "failed",
                taskName,
                error: updateResult.error,
              });
              logger?.error(`❌ [Step 3] Row ${i + 1}: Failed to update - ${updateResult.error}`);
              continue;
            }
          } else {
            action = "skipped";
            skippedCount++;
            opportunityTaskId = existingOpp.taskId;
            logger?.info(`⏭️ [Step 3] Row ${i + 1}: No changes detected, skipping`);
          }
        } else {
          // Opportunity doesn't exist - create new
          logger?.info(`✨ [Step 3] Row ${i + 1}: Creating new opportunity...`);
          const createResult = await createClickUpTaskTool.execute({
            context: {
              listId: getOpportunityListId(),
              taskData: row,
            },
            mastra,
            runtimeContext: {} as any,
          });

          if (!createResult.success) {
            failureCount++;
            results.push({
              rowIndex: i,
              action: "failed",
              taskName,
              error: createResult.error,
            });
            logger?.error(`❌ [Step 3] Row ${i + 1}: Failed to create - ${createResult.error}`);
            continue;
          }

          action = "created";
          createdCount++;
          opportunityTaskId = createResult.taskId!;
          logger?.info(`✅ [Step 3] Row ${i + 1}: Created new opportunity - ${opportunityTaskId}`);
        }

        // Handle Account relationship (for both new and updated opportunities)
        let accountTaskId: string | undefined;
        let accountLinked = false;

        if (accountName && opportunityTaskId) {
          const accountNameKey = accountName.toLowerCase();

          // Check cache first
          if (accountCache.has(accountNameKey)) {
            accountTaskId = accountCache.get(accountNameKey);
            logger?.info(`🔍 [Step 3] Row ${i + 1}: Found cached Account "${accountName}" (${accountTaskId})`);
          } else {
            // Search for existing Account task
            logger?.info(`🔍 [Step 3] Row ${i + 1}: Searching for Account "${accountName}"...`);
            const searchResult = await searchClickUpTasksTool.execute({
              context: {
                listId: getAccountListId(),
                searchQuery: accountName,
              },
              mastra,
              runtimeContext: {} as any,
            });

            if (searchResult.success && searchResult.tasks.length > 0) {
              accountTaskId = searchResult.tasks[0].id;
              accountCache.set(accountNameKey, accountTaskId);
              logger?.info(`🔍 [Step 3] Row ${i + 1}: Found existing Account (${accountTaskId})`);
            } else {
              // Create new account
              logger?.info(`🏢 [Step 3] Row ${i + 1}: Creating new Account "${accountName}"...`);
              const createAccountResult = await createAccountTaskTool.execute({
                context: { accountName },
                mastra,
                runtimeContext: {} as any,
              });

              if (createAccountResult.success && createAccountResult.taskId) {
                accountTaskId = createAccountResult.taskId;
                accountCache.set(accountNameKey, accountTaskId);
                accountsCreated++;
                logger?.info(`🏢 [Step 3] Row ${i + 1}: Created Account (${accountTaskId})`);
              } else {
                logger?.warn(`⚠️ [Step 3] Row ${i + 1}: Failed to create Account - ${createAccountResult.error}`);
              }
            }
          }

          // Link Opportunity to Account (only for new opportunities)
          if (accountTaskId && action === "created") {
            logger?.info(`🔗 [Step 3] Row ${i + 1}: Linking Opportunity to Account...`);
            const linkResult = await linkClickUpTasksTool.execute({
              context: {
                taskId: opportunityTaskId,
                linksToTaskId: accountTaskId,
              },
              mastra,
              runtimeContext: {} as any,
            });

            if (linkResult.success) {
              accountLinked = true;
              accountsLinked++;
              logger?.info(`🔗 [Step 3] Row ${i + 1}: Linked to Account successfully`);
            } else {
              logger?.warn(`⚠️ [Step 3] Row ${i + 1}: Failed to link - ${linkResult.error}`);
            }
          }
        }

        results.push({
          rowIndex: i,
          action,
          taskId: opportunityTaskId,
          taskName,
          accountId: accountTaskId,
          accountLinked,
          fieldsUpdated: action === "updated" ? fieldsUpdated : undefined,
        });

        // Rate limiting between tasks
        if (i < rows.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 300));
        }
      } catch (error) {
        failureCount++;
        const errorMessage = error instanceof Error ? error.message : String(error);
        results.push({
          rowIndex: i,
          action: "failed",
          taskName,
          error: errorMessage,
        });
        logger?.error(`❌ [Step 3] Row ${i + 1}: Exception - ${errorMessage}`);
      }
    }

    const summary = `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 CSV TO CLICKUP SYNC COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📂 Source File: ${inputData.fileInfo?.filename || "N/A"}

📈 Results:
  • Total Rows: ${rows.length}
  • ✨ New Opportunities Created: ${createdCount}
  • 🔄 Opportunities Updated: ${updatedCount}
  • ⏭️ Skipped (No Changes): ${skippedCount}
  • ❌ Failed: ${failureCount}

🏢 Account Relationships:
  • New Accounts Created: ${accountsCreated}
  • New Links Created: ${accountsLinked}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

    logger?.info(summary);

    return {
      success: failureCount === 0,
      totalRows: rows.length,
      createdCount,
      updatedCount,
      skippedCount,
      failureCount,
      accountsCreated,
      accountsLinked,
      results,
      summary,
    };
  },
});

// Helper function to get access token for workflow - uses config for environment-aware token
async function getAccessTokenForWorkflow() {
  const config = getClickUpConfig();
  return config.getAccessToken();
}

export const csvToClickUpWorkflow = createWorkflow({
  id: "csv-to-clickup-sync",

  inputSchema: z.object({}) as any,

  outputSchema: z.object({
    success: z.boolean(),
    totalRows: z.number(),
    createdCount: z.number(),
    updatedCount: z.number(),
    skippedCount: z.number(),
    failureCount: z.number(),
    accountsCreated: z.number(),
    accountsLinked: z.number(),
    results: z.array(
      z.object({
        rowIndex: z.number(),
        action: z.enum(["created", "updated", "skipped", "failed"]),
        taskId: z.string().optional(),
        taskName: z.string().optional(),
        accountId: z.string().optional(),
        accountLinked: z.boolean().optional(),
        fieldsUpdated: z.number().optional(),
        error: z.string().optional(),
      })
    ),
    summary: z.string(),
  }),
})
  .then(fetchEmailCsv as any)
  .then(fetchCsvFile as any)
  .then(parseCsvData as any)
  .then(processAllRows as any)
  .commit();
