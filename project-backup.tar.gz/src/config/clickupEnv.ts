export type ClickUpEnvironment = "production" | "staging";

interface FieldConfig {
  id: string;
  type: string;
  options?: Record<string, string>;
}

interface ClickUpEnvConfig {
  apiBaseUrl: string;
  workspaceId: string;
  opportunityListId: string;
  accountListId: string;
  fieldMap: Record<string, FieldConfig>;
  getAccessToken: () => Promise<string>;
}

let productionConnectionSettings: any;

async function getProductionAccessToken(): Promise<string> {
  if (
    productionConnectionSettings &&
    productionConnectionSettings.settings.expires_at &&
    new Date(productionConnectionSettings.settings.expires_at).getTime() > Date.now()
  ) {
    return productionConnectionSettings.settings.access_token;
  }

  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  if (!xReplitToken) {
    throw new Error("X_REPLIT_TOKEN not found for repl/depl");
  }

  productionConnectionSettings = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=clickup",
    {
      headers: {
        Accept: "application/json",
        X_REPLIT_TOKEN: xReplitToken,
      },
    }
  )
    .then((res) => res.json())
    .then((data) => data.items?.[0]);

  const accessToken =
    productionConnectionSettings?.settings?.access_token ||
    productionConnectionSettings.settings?.oauth?.credentials?.access_token;

  if (!productionConnectionSettings || !accessToken) {
    throw new Error("ClickUp not connected");
  }
  return accessToken;
}

async function getStagingAccessToken(): Promise<string> {
  const token = process.env.CLICKUP_STAGING_API_KEY;
  if (!token) {
    throw new Error("CLICKUP_STAGING_API_KEY not set");
  }
  return token;
}

const PRODUCTION_FIELD_MAP: Record<string, FieldConfig> = {
  "Opportunity ID": { id: "a58ff011-c194-455f-8926-bd37bff35d1c", type: "short_text" },
  "Account Name": { id: "5e8f3bf4-a5bd-4906-be25-2c51028ee480", type: "short_text" },
  "Sales Estimated Quota Relief": { id: "7392206d-35cc-48e7-98ab-f8f699ab121d", type: "currency" },
  "Stage": { 
    id: "3663452f-ec3e-4664-a81d-9865006813b4", 
    type: "drop_down",
    options: {
      "0": "18a32335-0274-4273-a343-9408a9d4da9c",
      "1": "02b74b9e-4372-4369-b14f-047c32c04f1b",
      "2": "b2427b5b-6726-44da-9780-305946b6f2a7",
      "3": "8bdeafa4-4f19-43a5-9f2d-f921afb34868",
      "4": "06a81fdc-c97c-40b7-9063-7b482ca7603b",
      "5": "f523162f-18f9-4f74-8c70-fff2288f694c",
      "Closed Won": "65754e43-4e43-4324-b70f-f021d939b5c0",
      "Closed Lost": "a09788ea-eceb-4fec-a50a-208abf1bbd38",
      "0 - Pre-Acceptance": "18a32335-0274-4273-a343-9408a9d4da9c",
      "1 - Initial Interest": "02b74b9e-4372-4369-b14f-047c32c04f1b",
      "2 - Investigate & Educate": "b2427b5b-6726-44da-9780-305946b6f2a7",
      "3 - Proposal": "8bdeafa4-4f19-43a5-9f2d-f921afb34868",
      "3 - Validate & Justify": "8bdeafa4-4f19-43a5-9f2d-f921afb34868",
      "4 - Negotiation": "06a81fdc-c97c-40b7-9063-7b482ca7603b",
      "4 - Finalize": "06a81fdc-c97c-40b7-9063-7b482ca7603b",
      "4 - Paper Process": "06a81fdc-c97c-40b7-9063-7b482ca7603b",
      "5 - Closing": "f523162f-18f9-4f74-8c70-fff2288f694c",
      "6 - Closed Won": "65754e43-4e43-4324-b70f-f021d939b5c0",
      "7 - Closed Lost": "a09788ea-eceb-4fec-a50a-208abf1bbd38",
      "Discovery": "18a32335-0274-4273-a343-9408a9d4da9c",
      "Qualification": "02b74b9e-4372-4369-b14f-047c32c04f1b",
      "Proposal": "b2427b5b-6726-44da-9780-305946b6f2a7",
      "Negotiation": "8bdeafa4-4f19-43a5-9f2d-f921afb34868",
    }
  },
  "Close Date": { id: "5d311a08-6754-4a8c-99e0-bcb8c1012f72", type: "date" },
  "Next Step Date": { id: "64697fcd-5733-48b8-bd0d-cbef7e3c7dce", type: "date" },
  "Next Step": { id: "99342f40-a536-4418-9157-3684cd03accd", type: "short_text" },
  "Metrics": { id: "a162d75e-df3c-45a2-b63b-37510b21405b", type: "text" },
  "Economic Buyer": { id: "013518f4-1074-48a5-b794-8783d07a7f9c", type: "short_text" },
  "Decision Criteria": { id: "e5b6def3-7b99-4051-af02-4831dd8ca979", type: "text" },
  "Decision Process": { id: "a5a7ad77-5994-4a87-9f9c-15f1f06c8501", type: "text" },
  "Paper Process": { id: "2c86d2f9-5a48-419c-93a5-ee721e6ecab2", type: "text" },
  "Implicated Pain": { id: "5f6b7ee6-0dd6-4e32-9e6d-404a33655453", type: "text" },
  "Champion Name": { id: "91791d4e-a770-42ad-9384-49e4c96d3c92", type: "short_text" },
  "Competitor": { id: "5f168250-660b-44c7-86f8-91131862f15d", type: "short_text" },
  "Other Competitor": { id: "5f683daa-444c-4c7a-b1d1-5d967d952e31", type: "short_text" },
  "CUO Meeting Completed": { id: "1b9e048a-88cf-44f3-bb69-47d4cfef7683", type: "checkbox" },
  "Evaluation Agreed": { id: "f9bdf085-1415-46ed-8cff-7537af86d864", type: "checkbox" },
  "Pricing Discussed": { id: "c328f2fb-9bb7-4bc3-8723-e6b994ceb6cb", type: "checkbox" },
  "Decision Criteria Met": { id: "8e4ec299-62da-4361-bd96-d418554631ee", type: "checkbox" },
  "Economic Buyer Approved": { id: "cd030471-ca49-4f86-987c-f11c3472673b", type: "checkbox" },
  "Ironclad Signatory": { id: "4888e5a2-c3da-4b89-88df-b164b253a4ec", type: "short_text" },
  "Mutual Action Plan (MAP) URL": { id: "204851bc-2d11-4bfe-99bd-d1bb71d736c7", type: "url" },
  "3 Whys Business Case": { id: "2ae96043-7076-4d80-95a4-fe07f1e59060", type: "url" },
  "Forecast Category": { 
    id: "33987465-3735-4011-ae5d-f66ca6237a3f", 
    type: "drop_down",
    options: {
      "Best Case": "4e724085-3d5d-46b9-a4bd-e695a5528f35",
      "Likely": "b29ddf40-48e1-42f3-bd96-ad6e72d3bafa",
      "Commit": "ca328ca1-687f-43b7-848c-b9d2c9176cd5",
      "Pipeline": "4e724085-3d5d-46b9-a4bd-e695a5528f35",
      "Closed Won": "ca328ca1-687f-43b7-848c-b9d2c9176cd5",
      "Closed Lost": "b29ddf40-48e1-42f3-bd96-ad6e72d3bafa",
    }
  },
  "Created Date": { id: "62fa2069-bf91-4d6b-bbf9-5e7a3753e898", type: "date" },
};

// Staging field map with staging-specific field IDs (from user's mapping file)
const STAGING_FIELD_MAP: Record<string, FieldConfig> = {
  "Opportunity ID": { id: "31cf5682-675c-4c44-9c83-ca1882ea944c", type: "short_text" },
  "Account Name": { id: "a3f48322-dba4-45db-b8e3-90965d68c78f", type: "short_text" },
  "Sales Estimated Quota Relief": { id: "55885f0d-eeb3-4d28-9ae2-8fba89d07e80", type: "currency" },
  "Stage": { 
    id: "70968f45-c169-46ef-a6b7-2383f3c3aca8", 
    type: "drop_down",
    options: {
      "0": "2c959e13-554d-448d-9468-e840e0b5babb",
      "1": "19143056-7265-4bd4-a448-e261db5a3310",
      "2": "f7a4af3e-882f-4358-8c01-d9d7628d1db6",
      "3": "7336c6d0-125a-45e6-aecc-c8293d67b698",
      "4": "edde4543-fee9-48c9-8516-1a474756c31e",
      "5": "edde4543-fee9-48c9-8516-1a474756c31e",
      "6": "a87bc1f2-b39e-4884-8cc2-3ed54b46388e",
      "0 - Pre Acceptance": "2c959e13-554d-448d-9468-e840e0b5babb",
      "0 - Pre-Acceptance": "2c959e13-554d-448d-9468-e840e0b5babb",
      "1 - Initial Interest": "19143056-7265-4bd4-a448-e261db5a3310",
      "2 - Investigate & Educate": "f7a4af3e-882f-4358-8c01-d9d7628d1db6",
      "3 - Proposal": "7336c6d0-125a-45e6-aecc-c8293d67b698",
      "3 - Validate & Justify": "7336c6d0-125a-45e6-aecc-c8293d67b698",
      "4 - Negotiation": "edde4543-fee9-48c9-8516-1a474756c31e",
      "4 - Finalize": "edde4543-fee9-48c9-8516-1a474756c31e",
      "4 - Paper Process": "edde4543-fee9-48c9-8516-1a474756c31e",
      "4 & 5 - Paper Process & Closing": "edde4543-fee9-48c9-8516-1a474756c31e",
      "5 - Closing": "edde4543-fee9-48c9-8516-1a474756c31e",
      "6 - Closed Won": "a87bc1f2-b39e-4884-8cc2-3ed54b46388e",
      "Closed Won": "a87bc1f2-b39e-4884-8cc2-3ed54b46388e",
      "7 - Closed Lost": "67d93608-1d17-40ba-aff4-1722934f964b",
      "Closed Lost": "67d93608-1d17-40ba-aff4-1722934f964b",
    }
  },
  "Close Date": { id: "620a9338-4c01-4891-b38f-9d7a3f50e435", type: "date" },
  "Next Step Date": { id: "10a3c04c-f833-4648-a86c-e7dc13b57be8", type: "date" },
  "Next Step": { id: "9c2d0b71-f5d3-4db7-9352-bc5de815d511", type: "text" },
  "Metrics": { id: "6f4df4d1-a637-4f2f-b6b7-163cea21effa", type: "text" },
  "Economic Buyer": { id: "77fd297b-3808-4293-ad2c-bb10a3541150", type: "short_text" },
  "Decision Criteria": { id: "85c85c0e-2359-4e0b-a1e5-187fdcdb1ed0", type: "text" },
  "Decision Process": { id: "391bf2f5-fdb7-422e-98aa-455fd4da35a3", type: "text" },
  "Paper Process": { id: "f25f7386-67dd-460c-a1c8-28e9c06cf241", type: "text" },
  "Implicated Pain": { id: "e7ee9395-97dc-4771-b50b-37e3b353a811", type: "text" },
  "Champion Name": { id: "83cf59b1-471f-4377-8777-ca4ed689aff0", type: "short_text" },
  "Competitor": { id: "14227952-bfc0-4af1-bf56-47744bb983e7", type: "short_text" },
  "Other Competitor": { id: "c07bb7c5-2652-40e3-8ad6-4a0b6ee98624", type: "short_text" },
  "CUO Meeting Completed": { id: "f70ce902-9a42-454c-8932-c80b839b45b5", type: "checkbox" },
  "Evaluation Agreed": { id: "c621ef7b-f5ea-4451-afeb-8ee228f771b7", type: "checkbox" },
  "Pricing Discussed": { id: "7d81f5fa-5804-4e95-8415-09db1ddcbb1b", type: "checkbox" },
  "Decision Criteria Met": { id: "e7de402d-12b3-4a86-a4d3-13e46905dd01", type: "checkbox" },
  "Economic Buyer Approved": { id: "6ba56ccd-85ff-4553-964c-118790a18468", type: "checkbox" },
  "Ironclad Signatory": { id: "acdfbd9c-32b8-4337-9415-b572c12a22ca", type: "short_text" },
  "Mutual Action Plan (MAP) URL": { id: "205a0c23-d8a0-413c-ba8a-52dbfa2c33e5", type: "url" },
  "3 Whys Business Case": { id: "06699cab-e589-4ceb-8d76-b530cd51f67b", type: "url" },
  "Forecast Category": { 
    id: "1704f039-5550-4484-9be1-0d13ce82f4cb", 
    type: "drop_down",
    options: {
      "Best Case": "7e6232aa-5350-4633-9123-adffeaf5f90f",
      "Likely": "8a1f2085-6edc-4ae0-bf06-27e7487d5844",
      "Commit": "28272d00-42a0-4493-89d9-c97ffdb585a3",
      "Pipeline": "7e6232aa-5350-4633-9123-adffeaf5f90f",
      "Closed Won": "28272d00-42a0-4493-89d9-c97ffdb585a3",
      "Closed Lost": "8a1f2085-6edc-4ae0-bf06-27e7487d5844",
    }
  },
  "Created Date": { id: "5e5da565-c8a6-4e9d-a008-523df0813056", type: "date" },
};

const ENVIRONMENTS: Record<ClickUpEnvironment, ClickUpEnvConfig> = {
  production: {
    apiBaseUrl: "https://api.clickup.com",
    workspaceId: "90161095683",
    opportunityListId: "901612392243",
    accountListId: "901613273568",
    fieldMap: PRODUCTION_FIELD_MAP,
    getAccessToken: getProductionAccessToken,
  },
  staging: {
    apiBaseUrl: "https://api.clickup-stg.com",
    workspaceId: "333",
    opportunityListId: "980700638489",
    accountListId: "980700638498",
    fieldMap: STAGING_FIELD_MAP,
    getAccessToken: getStagingAccessToken,
  },
};

export function getCurrentEnvironment(): ClickUpEnvironment {
  const env = process.env.CLICKUP_ENVIRONMENT?.toLowerCase();
  if (env === "staging") return "staging";
  return "production";
}

export function getClickUpConfig(): ClickUpEnvConfig {
  const env = getCurrentEnvironment();
  console.log(`🔧 [ClickUp] Using ${env.toUpperCase()} environment`);
  return ENVIRONMENTS[env];
}

export async function getClickUpClient() {
  const config = getClickUpConfig();
  const token = await config.getAccessToken();
  
  // @ts-ignore - clickup.js doesn't have type definitions
  const { Clickup } = await import("clickup.js");
  
  const client = new Clickup(token);
  
  if (getCurrentEnvironment() === "staging") {
    // For staging, we need to modify the axios instance base URL
    // The clickup.js library uses axios internally
    try {
      if (client.instance && client.instance.defaults) {
        client.instance.defaults.baseURL = config.apiBaseUrl;
      } else if (client._instance && client._instance.defaults) {
        client._instance.defaults.baseURL = config.apiBaseUrl;
      } else {
        // Try to find the axios instance on the client
        const axiosInstance = Object.values(client).find((val: any) => 
          val && typeof val === 'object' && val.defaults && val.defaults.baseURL
        );
        if (axiosInstance) {
          (axiosInstance as any).defaults.baseURL = config.apiBaseUrl;
        }
      }
    } catch (e) {
      console.warn("Could not set staging baseURL on clickup client, will use direct API calls");
    }
  }
  
  return client;
}

// For staging, we provide a direct fetch-based API that bypasses clickup.js
export async function createTaskDirect(listId: string, taskPayload: any) {
  const config = getClickUpConfig();
  const token = await config.getAccessToken();
  
  const response = await fetch(`${config.apiBaseUrl}/api/v2/list/${listId}/task`, {
    method: 'POST',
    headers: {
      'Authorization': token,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(taskPayload),
  });
  
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Failed to create task: ${response.status} ${errorBody}`);
  }
  
  return response.json();
}

export { ClickUpEnvConfig, FieldConfig };
