# Replit.md

## Overview

This is a Mastra-based AI automation framework for building agentic workflows with durable execution. The project syncs data from CSV files (likely Salesforce exports) to ClickUp tasks, using AI agents to orchestrate the process. It leverages Inngest for step-by-step workflow durability, ensuring workflows can recover from failures and resume execution.

The core automation reads opportunity data and syncs it to ClickUp custom fields based on a predefined field mapping (Salesforce → ClickUp).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Framework Stack
- **Mastra Framework**: Core AI agent and workflow orchestration library
- **Inngest**: Provides durable execution - workflows are memoized step-by-step so failures can resume from where they left off
- **TypeScript/ES Modules**: Modern ESM-based TypeScript project (Node 20.9+)

### Key Architectural Patterns

**Agent-Workflow Pattern**: Agents use LLMs for reasoning while workflows handle deterministic multi-step processes. Workflows call agents when AI reasoning is needed.

**Trigger Types**:
1. Time-based (Cron): Registered via `registerCronTrigger()` before Mastra initialization
2. Webhook-based: Slack, Telegram, and custom connectors using `registerApiRoute()`

**Inngest Integration**: Located in `src/mastra/inngest/`. This custom layer wraps Mastra workflows for durable execution. The integration is initialized in `src/mastra/index.ts` via:
```typescript
import { inngest, inngestServe } from "./inngest";
```

**Storage**: Uses `@mastra/pg` (PostgreSQL) via `sharedPostgresStorage` for workflow state persistence. Memory can also use `@mastra/libsql` for local development.

### Directory Structure
- `src/mastra/index.ts` - Main Mastra instance configuration
- `src/mastra/agents/` - AI agents with LLM reasoning capabilities
- `src/mastra/workflows/` - Multi-step workflow definitions
- `src/mastra/tools/` - Functions agents can call (APIs, databases, etc.)
- `src/mastra/inngest/` - Inngest durability layer configuration
- `src/triggers/` - Webhook and cron trigger handlers
- `docs/mastra/` - Framework documentation

### Workflow Development
- Workflows use `createWorkflow()` and `createStep()` from `@mastra/core/workflows`
- Steps define `inputSchema` and `outputSchema` using Zod
- Agents must use `.generateLegacy()` method for Replit Playground UI compatibility
- Workflows support suspend/resume for human-in-the-loop patterns

### Key Design Decisions

**Why Inngest over raw execution**: Provides automatic retries, step memoization, and resume-from-failure. If a 10-step workflow fails at step 7, it resumes from step 7 without re-running steps 1-6.

**Why Mastra**: TypeScript-native AI framework with built-in support for 40+ LLM providers, memory management, and workflow orchestration.

**Why PostgreSQL storage**: Production-ready persistence for workflow snapshots and agent memory.

## External Dependencies

### AI/LLM Providers
- **OpenAI** (`@ai-sdk/openai`): Primary LLM provider
- **OpenRouter** (`@openrouter/ai-sdk-provider`): Alternative model routing
- **Vercel AI SDK** (`ai`): Underlying AI SDK for model interactions

### External Services
- **ClickUp** (`clickup.js`): Task management API for syncing opportunities
- **Google APIs** (`googleapis`): Google Sheets/Drive integration
- **Slack** (`@slack/web-api`): Slack bot and webhook handling
- **Inngest**: Workflow durability and event-driven execution (cloud + local dev)

### Data Storage
- **PostgreSQL** (`@mastra/pg`): Primary storage for workflow state and memory
- **LibSQL** (`@mastra/libsql`): SQLite-compatible local storage option
- **Drizzle ORM** (`drizzle-zod`): Schema validation for database models

### Utilities
- **Zod**: Schema validation throughout
- **Pino**: Structured logging
- **csv-parse**: CSV file parsing for data imports
- **p-limit/p-retry**: Concurrency control and retry logic

### Environment Variables Required
- `OPENAI_API_KEY`: OpenAI API access
- `SCHEDULE_CRON_EXPRESSION`: Optional cron override (default: `0 8 * * *`)
- `GMAIL_USER_EMAIL`: Gmail address for IMAP email fetching
- `GMAIL_APP_PASSWORD`: Gmail App Password (16-character) for IMAP access
- ClickUp access token via Replit Connectors
- Database connection strings for PostgreSQL

## CSV to ClickUp Sync Automation

### Workflow Steps
1. **Fetch Email CSV** (Step 0): Connects to Gmail via IMAP and downloads the latest CSV attachment from the "salesforce-report" label
2. **Fetch Local CSV** (Step 1): Reads the most recent CSV file from `./data` folder
3. **Parse CSV** (Step 2): Parses CSV content into structured data
4. **Process All Rows** (Step 3): Upserts opportunities to ClickUp using Opportunity ID as unique key

### Gmail Filter Setup (Required)
Create a Gmail filter to auto-label the daily report emails:
1. Go to Gmail Settings → Filters → Create new filter
2. Subject contains: `JE - OPP REVIEW`
3. Has attachment: ✓
4. Actions: Apply label `salesforce-report`, Skip inbox (optional)

### Key Features
- **Email Integration**: Automatically fetches CSV attachments from Gmail "salesforce-report" label using IMAP with App Password
- **Upsert Logic**: Finds existing opportunities by Salesforce Opportunity ID, compares all fields, updates only when CSV differs
- **Account Linking**: Searches for or creates Account tasks and creates relationships between opportunities and accounts
- **Field Mapping**: Comprehensive mapping including MEDDPICC framework fields (Metrics, Economic Buyer, Decision Criteria, etc.)

### ClickUp Configuration
- **Opportunities List**: 901612392243
- **Accounts List**: 901613273568
- **Unique Identifier**: Opportunity ID custom field (Salesforce ID)

### Recent Changes
- 2026-01-30: Added IMAP email fetching for automated CSV retrieval
- 2026-01-30: Cleaned up 301 duplicate tasks, now 78 unique opportunities
- Fixed dropdown field comparison (skips when ClickUp returns indices)
- Fixed checkbox field comparison (accepts true/"true"/1/"1" as truthy)