import { Clickup } from "clickup.js";

async function getAccessToken() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  const connectionSettings = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=clickup",
    { headers: { Accept: "application/json", X_REPLIT_TOKEN: xReplitToken! } }
  )
    .then((res) => res.json())
    .then((data) => data.items?.[0]);

  return connectionSettings?.settings?.access_token;
}

async function main() {
  const token = await getAccessToken();
  const listId = "901612392243";
  
  // Use direct API call to get accessible custom fields
  const response = await fetch(`https://api.clickup.com/api/v2/list/${listId}/field`, {
    headers: {
      Authorization: token,
      "Content-Type": "application/json"
    }
  });
  const data = await response.json();
  
  console.log("Custom Fields Response:");
  console.log(JSON.stringify(data, null, 2));
}

main().catch(console.error);
