import { getClickUpConfig, getCurrentEnvironment } from "../src/config/clickupEnv.js";

async function main() {
  const env = getCurrentEnvironment();
  console.log("Environment:", env);
  
  const config = getClickUpConfig();
  const listId = config.opportunityListId;
  const token = await config.getAccessToken();
  const fieldMap = config.fieldMap;
  const oppIdFieldId = fieldMap["Opportunity ID"]?.id;
  const apiBase = config.apiBaseUrl;
  
  console.log("List:", listId, "OppID Field:", oppIdFieldId, "API:", apiBase);
  
  let allTasks: any[] = [];
  let page = 0;
  while (true) {
    const url = `${apiBase}/api/v2/list/${listId}/task?include_closed=true&page=${page}`;
    const resp = await fetch(url, { headers: { Authorization: token } });
    const data = await resp.json() as any;
    const tasks = data.tasks || [];
    if (tasks.length === 0) break;
    allTasks = allTasks.concat(tasks);
    console.log(`Page ${page}: ${tasks.length} tasks (total: ${allTasks.length})`);
    page++;
  }
  
  console.log(`\nTotal tasks: ${allTasks.length}`);
  
  const byOppId: Record<string, any[]> = {};
  for (const task of allTasks) {
    const cf = task.custom_fields || [];
    const oppField = cf.find((f: any) => f.id === oppIdFieldId);
    const oppId = oppField?.value || "NO_OPP_ID";
    if (!byOppId[oppId]) byOppId[oppId] = [];
    byOppId[oppId].push({ id: task.id, name: task.name });
  }
  
  const dupes = Object.entries(byOppId).filter(([_, t]) => t.length > 1);
  console.log(`\nDuplicate Opp IDs: ${dupes.length}`);
  for (const [oppId, tasks] of dupes) {
    console.log(`\n  ${oppId} (${tasks.length} copies):`);
    for (const t of tasks) console.log(`    ${t.id}: ${t.name}`);
  }
  if (dupes.length === 0) console.log("No duplicates found!");
}
main().catch(console.error);
