// @ts-ignore - clickup.js doesn't have type definitions
import { Clickup } from "clickup.js";

const OPP_ID_FIELD_ID = "a58ff011-c194-455f-8926-bd37bff35d1c";
const LIST_ID = "901612392243";

async function getClickUpClient() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  if (!xReplitToken || !hostname) {
    throw new Error("REPLIT_CONNECTORS_HOSTNAME or token not found");
  }

  const res = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=clickup",
    {
      headers: {
        Accept: "application/json",
        X_REPLIT_TOKEN: xReplitToken,
      },
    }
  );
  
  const data = await res.json();
  const connectionSettings = data.items?.[0];
  const accessToken = connectionSettings?.settings?.access_token || 
                      connectionSettings?.settings?.oauth?.credentials?.access_token;
  
  if (!accessToken) throw new Error("ClickUp not connected");
  return new Clickup(accessToken);
}

async function findAndDeleteDuplicates() {
  console.log("🔍 Fetching all tasks from ClickUp...");
  
  const clickup = await getClickUpClient();
  const allTasks: any[] = [];
  let page = 0;
  
  while (true) {
    const response = await clickup.lists.getTasks(LIST_ID, { page, include_closed: true });
    const tasks = response?.body?.tasks || [];
    if (tasks.length === 0) break;
    
    allTasks.push(...tasks);
    console.log(`  Page ${page}: ${tasks.length} tasks (total: ${allTasks.length})`);
    page++;
  }
  
  console.log(`\n📊 Total tasks: ${allTasks.length}`);
  
  // Group by Opportunity ID
  const byOppId: Record<string, any[]> = {};
  
  for (const task of allTasks) {
    const customFields = task.custom_fields || [];
    const oppIdField = customFields.find((f: any) => f.id === OPP_ID_FIELD_ID);
    const oppId = oppIdField?.value || "NO_OPP_ID";
    
    if (!byOppId[oppId]) byOppId[oppId] = [];
    byOppId[oppId].push(task);
  }
  
  // Find duplicates (keep newest)
  const tasksToDelete: string[] = [];
  
  for (const [oppId, tasks] of Object.entries(byOppId)) {
    if (tasks.length > 1) {
      // Sort by date_created descending, keep newest
      tasks.sort((a, b) => Number(b.date_created) - Number(a.date_created));
      for (let i = 1; i < tasks.length; i++) {
        tasksToDelete.push(tasks[i].id);
      }
    }
  }
  
  console.log(`\n🗑️ Deleting ${tasksToDelete.length} duplicate tasks...`);
  
  let deleted = 0;
  let errors = 0;
  
  for (const taskId of tasksToDelete) {
    try {
      await clickup.tasks.delete(taskId);
      deleted++;
      if (deleted % 10 === 0) {
        console.log(`  Progress: ${deleted}/${tasksToDelete.length} deleted`);
      }
      // Small delay to avoid rate limiting
      await new Promise(r => setTimeout(r, 100));
    } catch (err: any) {
      console.error(`  ❌ Error deleting ${taskId}: ${err.message}`);
      errors++;
    }
  }
  
  console.log(`\n✅ Cleanup complete!`);
  console.log(`  • Deleted: ${deleted}`);
  console.log(`  • Errors: ${errors}`);
  console.log(`  • Remaining tasks: ${allTasks.length - deleted}`);
}

findAndDeleteDuplicates().catch(console.error);
