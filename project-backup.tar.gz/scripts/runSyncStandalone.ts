import { fetchEmailCsvTool } from "../src/mastra/tools/emailFetchTool";
import { fetchLocalCsvTool } from "../src/mastra/tools/localCsvTool";
import { parseCsvTool } from "../src/mastra/tools/csvParseTool";
import {
  createClickUpTaskTool,
  searchClickUpTasksTool,
  createAccountTaskTool,
  linkClickUpTasksTool,
  updateClickUpTaskTool,
  getAccountListId,
  getOpportunityListId,
  CSV_FIELD_MAP,
} from "../src/mastra/tools/clickupTool";
import { getClickUpConfig } from "../src/config/clickupEnv";

interface OpportunityCache {
  taskId: string;
  name: string;
  customFields: Array<{ id: string; name: string; value: any }>;
}

const opportunityCache: Map<string, OpportunityCache> = new Map();
const accountCache: Map<string, string> = new Map();

const mockMastra = {
  getLogger: () => ({
    info: (msg: string, args?: any) => console.log(msg, args ? JSON.stringify(args) : ""),
    warn: (msg: string, args?: any) => console.warn(msg, args ? JSON.stringify(args) : ""),
    error: (msg: string, args?: any) => console.error(msg, args ? JSON.stringify(args) : ""),
    debug: (_msg: string, _args?: any) => {},
  }),
} as any;

function compareFieldValues(csvValue: string, clickUpValue: any, fieldType: string, fieldOptions?: Record<string, string>): boolean {
  if (!csvValue || csvValue.trim() === "") return true;

  switch (fieldType) {
    case "short_text":
    case "text":
      if (clickUpValue === null || clickUpValue === undefined) return false;
      return String(csvValue).trim() === String(clickUpValue).trim();
    case "currency":
    case "number": {
      const csvNum = parseFloat(String(csvValue).replace(/[^0-9.-]/g, ""));
      const clickUpNum = parseFloat(String(clickUpValue || 0));
      if (isNaN(csvNum)) return true;
      return !isNaN(clickUpNum) && csvNum === clickUpNum;
    }
    case "date": {
      if (clickUpValue === null || clickUpValue === undefined) return false;
      let csvTimestamp: number;
      if (csvValue.includes('/')) {
        const parts = csvValue.split('/');
        if (parts.length === 3) {
          csvTimestamp = Date.UTC(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10), 12, 0, 0);
        } else return true;
      } else if (csvValue.includes('-')) {
        const parts = csvValue.split('-');
        if (parts.length === 3) {
          csvTimestamp = Date.UTC(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10), 12, 0, 0);
        } else return true;
      } else return true;
      const csvDate = new Date(csvTimestamp);
      const clickUpDate = new Date(Number(clickUpValue));
      return csvDate.toISOString().split('T')[0] === clickUpDate.toISOString().split('T')[0];
    }
    case "checkbox": {
      const csvBool = csvValue.toLowerCase() === "true" || csvValue === "1" || csvValue.toLowerCase() === "yes";
      const clickUpBool = clickUpValue === true || clickUpValue === "true" || clickUpValue === 1 || clickUpValue === "1";
      return csvBool === clickUpBool;
    }
    case "drop_down":
      if (fieldOptions) {
        const csvOptionId = fieldOptions[csvValue];
        if (!csvOptionId) return true;
        if (typeof clickUpValue === 'string' && clickUpValue.startsWith('opt_')) return csvOptionId === clickUpValue;
        return true;
      }
      return true;
    case "url":
      if (clickUpValue === null || clickUpValue === undefined) return false;
      return String(csvValue).trim() === String(clickUpValue).trim();
    default:
      if (clickUpValue === null || clickUpValue === undefined) return false;
      return String(csvValue).trim() === String(clickUpValue).trim();
  }
}

async function getAccessToken() {
  const config = getClickUpConfig();
  return config.getAccessToken();
}

async function runSync() {
  const startTime = Date.now();
  console.log("🚀 [Standalone Sync] Starting CSV to ClickUp sync...");
  console.log(`📅 Time: ${new Date().toISOString()}`);

  // Step 0: Fetch CSV from email
  console.log("\n📧 [Step 0] Checking for CSV in email...");
  const hasEmailConfig = process.env.GMAIL_USER_EMAIL && process.env.GMAIL_APP_PASSWORD;

  if (hasEmailConfig) {
    const emailResult = await fetchEmailCsvTool.execute({
      context: { daysBack: 2, labelName: "salesforce-report" },
      mastra: mockMastra,
      runtimeContext: {} as any,
    });

    if (!emailResult.success) {
      console.warn(`⚠️ [Step 0] Email fetch failed: ${emailResult.error} - will try local CSV`);
    } else {
      console.log(`✅ [Step 0] Downloaded CSV from email: ${emailResult.filename}`);
    }
  } else {
    console.log("📧 [Step 0] Email not configured, skipping email fetch...");
  }

  // Step 1: Fetch local CSV
  console.log("\n📂 [Step 1] Fetching CSV file from data folder...");
  const csvResult = await fetchLocalCsvTool.execute({
    context: { folder: "./data" },
    mastra: mockMastra,
    runtimeContext: {} as any,
  });

  if (!csvResult.success || !csvResult.csvContent) {
    console.error(`❌ [Step 1] Failed to fetch CSV: ${csvResult.error}`);
    process.exit(1);
  }
  console.log(`✅ [Step 1] Successfully fetched CSV: ${csvResult.filename}`);

  // Step 2: Parse CSV
  console.log("\n📊 [Step 2] Parsing CSV data...");
  const parseResult = await parseCsvTool.execute({
    context: { csvContent: csvResult.csvContent },
    mastra: mockMastra,
    runtimeContext: {} as any,
  });

  if (!parseResult.success || !parseResult.rows || parseResult.rows.length === 0) {
    console.error(`❌ [Step 2] Failed to parse CSV: ${parseResult.error}`);
    process.exit(1);
  }
  console.log(`✅ [Step 2] Successfully parsed ${parseResult.rowCount} rows`);

  // Step 3: Process all rows
  console.log("\n🔄 [Step 3] Processing CSV rows with upsert logic...");

  const rows = parseResult.rows;
  let createdCount = 0;
  let updatedCount = 0;
  let skippedCount = 0;
  let failureCount = 0;
  let accountsCreated = 0;
  let accountsLinked = 0;

  opportunityCache.clear();
  accountCache.clear();

  const token = await getAccessToken();

  // Pre-fetch existing opportunities
  console.log("📂 [Step 3] Fetching existing opportunities from ClickUp...");
  try {
    const opportunitiesResponse = await fetch(
      `${getClickUpConfig().apiBaseUrl}/api/v2/list/${getOpportunityListId()}/task?include_closed=true`,
      { headers: { 'Authorization': token, 'Content-Type': 'application/json' } }
    );

    if (opportunitiesResponse.ok) {
      const opportunitiesData = await opportunitiesResponse.json();
      const opportunityTasks = opportunitiesData.tasks || [];
      const opportunityIdFieldId = CSV_FIELD_MAP["Opportunity ID"]?.id;

      for (const task of opportunityTasks) {
        const customFields = task.custom_fields || [];
        const oppIdField = customFields.find((cf: any) => cf.id === opportunityIdFieldId);
        if (oppIdField && oppIdField.value) {
          opportunityCache.set(oppIdField.value, {
            taskId: task.id,
            name: task.name,
            customFields: customFields.map((cf: any) => ({ id: cf.id, name: cf.name, value: cf.value })),
          });
        }
      }
      console.log(`📂 [Step 3] Cached ${opportunityCache.size} existing opportunities`);
    }
  } catch (error) {
    console.warn(`⚠️ [Step 3] Could not pre-fetch opportunities: ${error}`);
  }

  // Pre-fetch existing accounts
  console.log("📂 [Step 3] Fetching existing accounts...");
  try {
    const accountsResponse = await fetch(
      `${getClickUpConfig().apiBaseUrl}/api/v2/list/${getAccountListId()}/task?include_closed=true`,
      { headers: { 'Authorization': token, 'Content-Type': 'application/json' } }
    );

    if (accountsResponse.ok) {
      const accountsData = await accountsResponse.json();
      const accountTasks = accountsData.tasks || [];
      for (const task of accountTasks) {
        accountCache.set(task.name.toLowerCase().trim(), task.id);
      }
      console.log(`📂 [Step 3] Cached ${accountCache.size} existing accounts`);
    }
  } catch (error) {
    console.warn(`⚠️ [Step 3] Could not pre-fetch accounts: ${error}`);
  }

  // Process each row
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const taskName = row["Opportunity Name"] || "Unknown";
    const opportunityId = row["Opportunity ID"]?.trim() || "";
    const accountName = row["Account Name"]?.trim() || "";

    console.log(`📝 [Step 3] Processing row ${i + 1}/${rows.length}: ${taskName} (Opp ID: ${opportunityId})`);

    if (!opportunityId) {
      failureCount++;
      console.error(`❌ [Step 3] Row ${i + 1}: Missing Opportunity ID`);
      continue;
    }

    try {
      let opportunityTaskId: string | undefined;
      let action: "created" | "updated" | "skipped" = "created";

      const existingOpp = opportunityCache.get(opportunityId);

      if (existingOpp) {
        console.log(`🔍 [Step 3] Row ${i + 1}: Found existing opportunity (${existingOpp.taskId})`);

        let needsUpdate = false;
        const existingFieldsMap = new Map(existingOpp.customFields.map(cf => [cf.id, cf.value]));

        for (const [csvField, fieldConfig] of Object.entries(CSV_FIELD_MAP)) {
          const csvValue = row[csvField];
          if (!csvValue || csvValue.trim() === "") continue;
          const clickUpValue = existingFieldsMap.get(fieldConfig.id);
          const isEqual = compareFieldValues(csvValue, clickUpValue, fieldConfig.type, fieldConfig.options);
          if (!isEqual) {
            needsUpdate = true;
            console.log(`  📝 Field "${csvField}" differs: CSV="${csvValue}" vs ClickUp="${clickUpValue}"`);
          }
        }

        if (taskName !== existingOpp.name) {
          needsUpdate = true;
          console.log(`  📝 Task name differs: CSV="${taskName}" vs ClickUp="${existingOpp.name}"`);
        }

        if (needsUpdate) {
          console.log(`🔄 [Step 3] Row ${i + 1}: Updating opportunity...`);
          const updateResult = await updateClickUpTaskTool.execute({
            context: { taskId: existingOpp.taskId, taskData: row },
            mastra: mockMastra,
            runtimeContext: {} as any,
          });

          if (updateResult.success) {
            action = "updated";
            updatedCount++;
            opportunityTaskId = existingOpp.taskId;
            console.log(`✅ [Step 3] Row ${i + 1}: Updated ${updateResult.fieldsUpdated || 0} fields`);
          } else {
            failureCount++;
            console.error(`❌ [Step 3] Row ${i + 1}: Failed to update - ${updateResult.error}`);
            continue;
          }
        } else {
          action = "skipped";
          skippedCount++;
          opportunityTaskId = existingOpp.taskId;
          console.log(`⏭️ [Step 3] Row ${i + 1}: No changes detected, skipping`);
        }
      } else {
        console.log(`✨ [Step 3] Row ${i + 1}: Creating new opportunity...`);
        const createResult = await createClickUpTaskTool.execute({
          context: { listId: getOpportunityListId(), taskData: row },
          mastra: mockMastra,
          runtimeContext: {} as any,
        });

        if (!createResult.success) {
          failureCount++;
          console.error(`❌ [Step 3] Row ${i + 1}: Failed to create - ${createResult.error}`);
          continue;
        }

        action = "created";
        createdCount++;
        opportunityTaskId = createResult.taskId!;
        console.log(`✅ [Step 3] Row ${i + 1}: Created new opportunity - ${opportunityTaskId}`);
      }

      // Handle Account relationship
      if (accountName && opportunityTaskId) {
        const accountNameKey = accountName.toLowerCase();
        let accountTaskId: string | undefined;

        if (accountCache.has(accountNameKey)) {
          accountTaskId = accountCache.get(accountNameKey);
          console.log(`🔍 [Step 3] Row ${i + 1}: Found cached Account "${accountName}" (${accountTaskId})`);
        } else {
          console.log(`🔍 [Step 3] Row ${i + 1}: Searching for Account "${accountName}"...`);
          const searchResult = await searchClickUpTasksTool.execute({
            context: { listId: getAccountListId(), searchQuery: accountName },
            mastra: mockMastra,
            runtimeContext: {} as any,
          });

          if (searchResult.success && searchResult.tasks.length > 0) {
            accountTaskId = searchResult.tasks[0].id;
            accountCache.set(accountNameKey, accountTaskId);
            console.log(`🔍 [Step 3] Row ${i + 1}: Found existing Account (${accountTaskId})`);
          } else {
            console.log(`🏢 [Step 3] Row ${i + 1}: Creating new Account "${accountName}"...`);
            const createAccountResult = await createAccountTaskTool.execute({
              context: { accountName },
              mastra: mockMastra,
              runtimeContext: {} as any,
            });

            if (createAccountResult.success && createAccountResult.taskId) {
              accountTaskId = createAccountResult.taskId;
              accountCache.set(accountNameKey, accountTaskId);
              accountsCreated++;
              console.log(`🏢 [Step 3] Row ${i + 1}: Created Account (${accountTaskId})`);
            } else {
              console.warn(`⚠️ [Step 3] Row ${i + 1}: Failed to create Account - ${createAccountResult.error}`);
            }
          }
        }

        if (accountTaskId && action === "created") {
          console.log(`🔗 [Step 3] Row ${i + 1}: Linking Opportunity to Account...`);
          const linkResult = await linkClickUpTasksTool.execute({
            context: { taskId: opportunityTaskId, linksToTaskId: accountTaskId },
            mastra: mockMastra,
            runtimeContext: {} as any,
          });

          if (linkResult.success) {
            accountsLinked++;
            console.log(`🔗 [Step 3] Row ${i + 1}: Linked to Account successfully`);
          } else {
            console.warn(`⚠️ [Step 3] Row ${i + 1}: Failed to link - ${linkResult.error}`);
          }
        }
      }

      if (i < rows.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
    } catch (error) {
      failureCount++;
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`❌ [Step 3] Row ${i + 1}: Exception - ${errorMessage}`);
    }
  }

  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

  const summary = `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 CSV TO CLICKUP SYNC COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📂 Source File: ${csvResult.filename || "N/A"}
⏱️ Duration: ${elapsed}s

📈 Results:
  • Total Rows: ${rows.length}
  • ✨ New Opportunities Created: ${createdCount}
  • 🔄 Opportunities Updated: ${updatedCount}
  • ⏭️ Skipped (No Changes): ${skippedCount}
  • ❌ Failed: ${failureCount}

🏢 Account Relationships:
  • New Accounts Created: ${accountsCreated}
  • New Links Created: ${accountsLinked}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  console.log(summary);

  if (failureCount > 0) {
    process.exit(1);
  }
  process.exit(0);
}

runSync().catch((error) => {
  console.error("❌ [Standalone Sync] Fatal error:", error);
  process.exit(1);
});
