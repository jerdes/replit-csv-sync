import { inngest } from "../src/mastra/inngest";

async function triggerWorkflow() {
  console.log("🕐 Scheduled trigger starting...");
  console.log(`📅 Time: ${new Date().toISOString()}`);
  
  try {
    await inngest.send({
      name: "replit/cron.trigger",
      data: {},
    });
    
    console.log("✅ Workflow triggered successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Failed to trigger workflow:", error);
    process.exit(1);
  }
}

triggerWorkflow();
