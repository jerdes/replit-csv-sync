// @ts-ignore - clickup.js doesn't have type definitions
import { Clickup } from "clickup.js";

const LIST_ID = "901612392243"; // Opportunities list
const OPP_ID_FIELD_ID = "a58ff011-c194-455f-8926-bd37bff35d1c"; // Correct ID

async function getClickUpClient() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  if (!xReplitToken || !hostname) {
    throw new Error("REPLIT_CONNECTORS_HOSTNAME or token not found");
  }

  const res = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=clickup",
    {
      headers: {
        Accept: "application/json",
        X_REPLIT_TOKEN: xReplitToken,
      },
    }
  );
  
  const data = await res.json();
  const connectionSettings = data.items?.[0];
  const accessToken = connectionSettings?.settings?.access_token || 
                      connectionSettings?.settings?.oauth?.credentials?.access_token;
  
  if (!accessToken) throw new Error("ClickUp not connected");
  return new Clickup(accessToken);
}

async function findDuplicates() {
  console.log("🔍 Fetching all tasks from ClickUp...");
  
  const clickup = await getClickUpClient();
  const allTasks: any[] = [];
  let page = 0;
  
  while (true) {
    const response = await clickup.lists.getTasks(LIST_ID, { page, include_closed: true });
    const tasks = response?.body?.tasks || [];
    if (tasks.length === 0) break;
    
    allTasks.push(...tasks);
    console.log(`  Page ${page}: ${tasks.length} tasks (total: ${allTasks.length})`);
    page++;
  }
  
  console.log(`\n📊 Total tasks: ${allTasks.length}`);
  
  // Group by Opportunity ID
  const byOppId: Record<string, any[]> = {};
  
  for (const task of allTasks) {
    const customFields = task.custom_fields || [];
    const oppIdField = customFields.find((f: any) => f.id === OPP_ID_FIELD_ID);
    const oppId = oppIdField?.value || "NO_OPP_ID";
    
    if (!byOppId[oppId]) byOppId[oppId] = [];
    byOppId[oppId].push(task);
  }
  
  // Find duplicates
  const duplicates = Object.entries(byOppId)
    .filter(([_, tasks]) => tasks.length > 1)
    .map(([oppId, tasks]) => ({
      oppId,
      count: tasks.length,
      tasks: tasks.map(t => ({ id: t.id, name: t.name, date_created: t.date_created }))
    }));
  
  console.log(`\n🔍 Found ${duplicates.length} Opportunity IDs with duplicates:`);
  
  let totalDuplicates = 0;
  for (const dup of duplicates) {
    console.log(`\n  ${dup.oppId}: ${dup.count} copies`);
    // Sort by date_created descending, keep newest
    dup.tasks.sort((a, b) => Number(b.date_created) - Number(a.date_created));
    for (let i = 0; i < dup.tasks.length; i++) {
      const t = dup.tasks[i];
      const marker = i === 0 ? "✓ KEEP" : "✗ DELETE";
      console.log(`    ${marker}: ${t.id} - ${t.name}`);
      if (i > 0) totalDuplicates++;
    }
  }
  
  console.log(`\n📋 Summary: ${totalDuplicates} duplicate tasks to delete`);
  
  // Return task IDs to delete
  const tasksToDelete = duplicates.flatMap(d => d.tasks.slice(1).map(t => t.id));
  console.log(`\n🗑️ Task IDs to delete (${tasksToDelete.length}): ${JSON.stringify(tasksToDelete)}`);
  
  return tasksToDelete;
}

findDuplicates().catch(console.error);
