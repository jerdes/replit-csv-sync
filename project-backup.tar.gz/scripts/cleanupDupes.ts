import { getClickUpConfig, getCurrentEnvironment } from "../src/config/clickupEnv.js";

async function main() {
  const env = getCurrentEnvironment();
  console.log("Environment:", env);
  
  const config = getClickUpConfig();
  const listId = config.opportunityListId;
  const token = await config.getAccessToken();
  const fieldMap = config.fieldMap;
  const oppIdFieldId = fieldMap["Opportunity ID"]?.id;
  const apiBase = config.apiBaseUrl;
  
  // Fetch all tasks with pagination
  let allTasks: any[] = [];
  let page = 0;
  while (true) {
    const url = `${apiBase}/api/v2/list/${listId}/task?include_closed=true&page=${page}`;
    const resp = await fetch(url, { headers: { Authorization: token } });
    const data = await resp.json() as any;
    const tasks = data.tasks || [];
    if (tasks.length === 0) break;
    allTasks = allTasks.concat(tasks);
    page++;
  }
  console.log(`Total tasks: ${allTasks.length}`);
  
  // Group by Opportunity ID
  const byOppId: Record<string, any[]> = {};
  for (const task of allTasks) {
    const cf = task.custom_fields || [];
    const oppField = cf.find((f: any) => f.id === oppIdFieldId);
    const oppId = oppField?.value || "NO_OPP_ID";
    if (!byOppId[oppId]) byOppId[oppId] = [];
    byOppId[oppId].push(task);
  }
  
  const dupes = Object.entries(byOppId).filter(([_, t]) => t.length > 1);
  console.log(`\nDuplicate Opp IDs: ${dupes.length}`);
  
  let deleteCount = 0;
  const errors: string[] = [];
  
  for (const [oppId, tasks] of dupes) {
    // Sort by date_created ascending - keep the oldest, delete the newer ones
    tasks.sort((a: any, b: any) => parseInt(a.date_created) - parseInt(b.date_created));
    const keep = tasks[0];
    const toDelete = tasks.slice(1);
    
    for (const task of toDelete) {
      console.log(`  Deleting duplicate: ${task.id} (${task.name}) - keeping ${keep.id}`);
      try {
        const resp = await fetch(`${apiBase}/api/v2/task/${task.id}`, {
          method: 'DELETE',
          headers: { Authorization: token },
        });
        if (resp.ok) {
          deleteCount++;
        } else {
          const errText = await resp.text();
          errors.push(`Failed to delete ${task.id}: ${resp.status} ${errText}`);
          console.error(`  ERROR: ${resp.status} ${errText}`);
        }
        // Rate limit: wait between deletes
        await new Promise(r => setTimeout(r, 300));
      } catch (e) {
        errors.push(`Error deleting ${task.id}: ${e}`);
        console.error(`  ERROR: ${e}`);
      }
    }
  }
  
  console.log(`\nDeleted ${deleteCount} duplicate tasks`);
  if (errors.length > 0) {
    console.log(`Errors: ${errors.length}`);
    errors.forEach(e => console.log(`  ${e}`));
  }
  
  // Verify
  let remaining: any[] = [];
  page = 0;
  while (true) {
    const url = `${apiBase}/api/v2/list/${listId}/task?include_closed=true&page=${page}`;
    const resp = await fetch(url, { headers: { Authorization: token } });
    const data = await resp.json() as any;
    const tasks = data.tasks || [];
    if (tasks.length === 0) break;
    remaining = remaining.concat(tasks);
    page++;
  }
  console.log(`\nRemaining tasks after cleanup: ${remaining.length}`);
}

main().catch(console.error);
